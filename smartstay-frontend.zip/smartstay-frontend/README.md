# SmartStay Frontend

React + Vite + Material UI + Axios + React Router frontend for the uploaded SmartStay microservices backend.

## Run

```bash
npm install
npm run dev
```

Frontend: http://localhost:5173

API Gateway: http://localhost:8080

Optional `.env`:
```env
VITE_API_BASE_URL=http://localhost:8080
```

## Exact backend routes used

- Auth: `/auth/register`, `/auth/login`
- Users: `/users`, `/users/{id}`, `/users/auth/{authUserId}`, `/users/{userId}/preferences`
- PGs: `/pgs`, `/pgs/{id}`, `/pgs/owner/{ownerId}`, `/pgs/search`, `/pgs/{id}/status`
- Bookings: `/bookings`, `/bookings/{id}`, `/bookings/user/{userId}`, `/bookings/pg/{pgId}`, `/bookings/status/{status}`, `/bookings/{id}/status`
- Reviews: `/reviews`, `/reviews/{id}`, `/reviews/pg/{pgId}`, `/reviews/user/{userId}`, `/reviews/pg/{pgId}/average`
- Rooms: `/rooms/...`
- Amenities: `/amenities/...`

## Important

The uploaded backend originally had API Gateway routes only for Auth and PG services. The patched backend included with this integration adds Gateway routes for User, Booking, Review, Room and Amenity endpoints.

The backend currently has authorization enforced in Auth Service, while the API Gateway security configuration permits all requests and User/PG/Booking/Review services do not independently enforce JWT authorization. This is acceptable for local integration testing, but **it is not production-grade security**. Before deployment, JWT validation/authorization should be enforced at the gateway or each protected service.

Forgot Password is intentionally a UI page only because the uploaded backend has no password-reset controller/service.

PG creation sends the backend's exact `ownerId` and `monthlyRent` fields. Booking creation sends the backend's exact `CreateBookingRequest` fields; rent/security-deposit are calculated by Booking Service and are not sent by the frontend.
