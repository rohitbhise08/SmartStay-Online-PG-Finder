export const TOKEN_KEY = "smartstay_token";
export const USER_KEY = "smartstay_user";

export function saveToken(token) {
  localStorage.setItem(TOKEN_KEY, token);
}

export function getToken() {
  return localStorage.getItem(TOKEN_KEY);
}

export function removeToken() {
  localStorage.removeItem(TOKEN_KEY);
}

export function decodeJwt(token) {
  try {
    const payload = token.split(".")[1];
    return JSON.parse(atob(payload.replace(/-/g, "+").replace(/_/g, "/")));
  } catch {
    return null;
  }
}

export function saveUser(user) {
  localStorage.setItem(USER_KEY, JSON.stringify(user));
}

export function getStoredUser() {
  try {
    return JSON.parse(localStorage.getItem(USER_KEY) || "null");
  } catch {
    return null;
  }
}

export function clearAuth() {
  removeToken();
  localStorage.removeItem(USER_KEY);
}

export function getRoleFromToken(token = getToken()) {
  const payload = decodeJwt(token);
  if (!payload) return null;
  const roles = payload.roles || payload.authorities || payload.role || payload.roles;
  if (Array.isArray(roles)) return roles[0];
  return roles || null;
}
