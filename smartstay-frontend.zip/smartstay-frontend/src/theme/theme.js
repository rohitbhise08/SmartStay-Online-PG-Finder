import { createTheme } from "@mui/material/styles";

const theme = createTheme({
  palette: {
    primary: { main: "#1565ff", dark: "#0b43b8", light: "#eaf1ff" },
    secondary: { main: "#111827" },
    background: { default: "#f7f9fc", paper: "#ffffff" },
    success: { main: "#159957" },
    warning: { main: "#f59e0b" },
    error: { main: "#dc2626" },
  },
  typography: {
    fontFamily: '"Inter", "Roboto", "Helvetica", "Arial", sans-serif',
    h1: { fontWeight: 800 },
    h2: { fontWeight: 800 },
    h3: { fontWeight: 800 },
    h4: { fontWeight: 800 },
    h5: { fontWeight: 750 },
    button: { textTransform: "none", fontWeight: 700 },
  },
  shape: { borderRadius: 14 },
  components: {
    MuiButton: {
      styleOverrides: {
        root: { borderRadius: 10, paddingInline: 18 },
      },
    },
    MuiCard: {
      styleOverrides: {
        root: { boxShadow: "0 8px 30px rgba(15,23,42,.07)" },
      },
    },
    MuiTextField: {
      defaultProps: { size: "small" },
    },
  },
});

export default theme;
