import { createContext, useContext, useEffect, useMemo, useState } from "react";
import axios from "../api/axiosInstance";
import { API } from "../api/apiEndpoints";
import {
  clearAuth,
  decodeJwt,
  getRoleFromToken,
  getStoredUser,
  getToken,
  saveToken,
  saveUser,
} from "../utils/tokenUtils";

const AuthContext = createContext(null);

function normalizeUser(response, token) {
  const data = response?.data || response || {};
  const payload = decodeJwt(token) || {};
  return {
    id: data.userId ?? data.id ?? payload.userId ?? payload.id ?? null,
    fullName: data.fullName ?? data.name ?? payload.fullName ?? payload.name ?? "",
    email: data.email ?? payload.email ?? "",
    phone: data.phone ?? "",
    role: data.role ?? payload.role ?? getRoleFromToken(token) ?? "ROLE_USER",
  };
}

export function AuthProvider({ children }) {
  const [token, setToken] = useState(getToken());
  const [user, setUser] = useState(getStoredUser());

  useEffect(() => {
    const current = getToken();
    if (current && !user) {
      const payload = decodeJwt(current);
      const restored = {
        id: payload?.userId ?? payload?.id ?? null,
        fullName: payload?.fullName ?? payload?.name ?? "",
        email: payload?.email ?? "",
        role: getRoleFromToken(current) || "ROLE_USER",
      };
      setUser(restored);
      saveUser(restored);
    }
  }, []);

  const login = async (credentials) => {
    const response = await axios.post(API.AUTH.LOGIN, credentials);
    const data = response.data || {};
    const newToken = data.token || data.jwt || data.accessToken;
    if (!newToken) throw new Error("Login succeeded but no JWT token was returned by the backend.");

    const normalized = normalizeUser(data, newToken);
    saveToken(newToken);
    saveUser(normalized);
    setToken(newToken);
    setUser(normalized);
    return normalized;
  };

  const register = async (payload) => {
    const response = await axios.post(API.AUTH.REGISTER, payload);
    const data = response.data || {};
    const newToken = data.token || data.jwt || data.accessToken;

    if (newToken) {
      const normalized = normalizeUser(data, newToken);
      saveToken(newToken);
      saveUser(normalized);
      setToken(newToken);
      setUser(normalized);
    }
    return response;
  };

  const logout = () => {
    clearAuth();
    setToken(null);
    setUser(null);
  };

  const value = useMemo(
    () => ({
      token,
      user,
      isAuthenticated: Boolean(token),
      isAdmin:
        String(user?.role || "").toUpperCase().includes("ADMIN") ||
        String(getRoleFromToken(token) || "").toUpperCase().includes("ADMIN"),
      login,
      register,
      logout,
    }),
    [token, user]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  return useContext(AuthContext);
}
