import { Box, Typography } from "@mui/material";

export default function EmptyState({ title = "Nothing here yet", text = "No records were found." }) {
  return (
    <Box sx={{ textAlign: "center", py: 8 }}>
      <Typography variant="h6" fontWeight={800}>{title}</Typography>
      <Typography color="text.secondary">{text}</Typography>
    </Box>
  );
}
