import { Alert } from "@mui/material";

export default function ErrorMessage({ error, sx }) {
  if (!error) return null;
  const message =
    error?.response?.data?.message ||
    error?.response?.data?.error ||
    error?.message ||
    "Something went wrong.";
  return <Alert severity="error" sx={{ mb: 2, ...sx }}>{message}</Alert>;
}
