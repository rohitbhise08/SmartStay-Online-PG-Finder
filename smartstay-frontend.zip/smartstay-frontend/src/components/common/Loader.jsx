import { Box, CircularProgress } from "@mui/material";

export default function Loader({ fullPage = false }) {
  return (
    <Box sx={{ minHeight: fullPage ? "60vh" : 160, display: "grid", placeItems: "center" }}>
      <CircularProgress />
    </Box>
  );
}
