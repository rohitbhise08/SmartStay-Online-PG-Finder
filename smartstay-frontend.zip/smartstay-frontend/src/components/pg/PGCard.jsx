import {
  Box,
  Button,
  Card,
  CardContent,
  Chip,
  Stack,
  Typography,
} from "@mui/material";

import {
  LocationOnRounded,
  WifiRounded,
  RestaurantRounded,
  LocalParkingRounded,
  KingBedRounded,
  ArrowForwardRounded,
} from "@mui/icons-material";

import { Link } from "react-router-dom";

const fallback =
  "https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=1000&q=85";

export default function PGCard({ pg }) {

  const image =
    pg.imageUrl ||
    pg.image ||
    pg.photoUrl ||
    fallback;

  const rent =
    pg.monthlyRent ??
    pg.rent ??
    0;

  return (
    <Card
      sx={{
        height: "100%",
        borderRadius: 4,
        overflow: "hidden",
        backgroundColor: "#ffffff",
        border: "1px solid #e8ecf2",
        boxShadow: "0 8px 30px rgba(15, 23, 42, 0.06)",
        transition: "all 0.3s ease",

        "&:hover": {
          transform: "translateY(-7px)",
          boxShadow: "0 18px 45px rgba(15, 23, 42, 0.14)",
        },
      }}
    >

      {/* IMAGE */}
      <Box
        sx={{
          position: "relative",
          height: 240,
          overflow: "hidden",
        }}
      >

        <Box
          component="img"
          src={image}
          alt={pg.name || "PG"}
          sx={{
            width: "100%",
            height: "100%",
            objectFit: "cover",
            display: "block",
            transition: "transform 0.5s ease",

            "&:hover": {
              transform: "scale(1.05)",
            },
          }}
        />

        {/* STATUS */}
        {pg.status && (
          <Chip
            label={String(pg.status).replaceAll("_", " ")}
            size="small"
            sx={{
              position: "absolute",
              top: 16,
              left: 16,
              backgroundColor:
                pg.status === "ACTIVE"
                  ? "#16a34a"
                  : "#f59e0b",
              color: "#fff",
              fontWeight: 800,
              fontSize: 12,
              borderRadius: 2,
            }}
          />
        )}

        {/* PROPERTY TYPE */}
        <Chip
          label={pg.propertyType || "PG"}
          size="small"
          sx={{
            position: "absolute",
            top: 16,
            right: 16,
            backgroundColor: "rgba(255,255,255,0.94)",
            color: "#111827",
            fontWeight: 700,
            borderRadius: 2,
          }}
        />

      </Box>


      {/* CONTENT */}
      <CardContent
        sx={{
          p: 2.5,
        }}
      >

        {/* NAME */}
        <Typography
          variant="h6"
          sx={{
            fontWeight: 900,
            color: "#111827",
            fontSize: 20,
            mb: 0.5,
          }}
        >
          {pg.name || "PG Accommodation"}
        </Typography>


        {/* LOCATION */}
        <Stack
          direction="row"
          alignItems="center"
          spacing={0.5}
          sx={{
            color: "#64748b",
            mb: 2,
          }}
        >
          <LocationOnRounded
            sx={{
              fontSize: 19,
              color: "#2563eb",
            }}
          />

          <Typography
            variant="body2"
            sx={{
              fontWeight: 500,
            }}
          >
            {pg.area ? `${pg.area}, ` : ""}
            {pg.city || "Location"}
          </Typography>
        </Stack>


        {/* RENT */}
        <Box
          sx={{
            display: "flex",
            alignItems: "baseline",
            gap: 0.7,
            mb: 2,
          }}
        >

          <Typography
            sx={{
              fontSize: 25,
              fontWeight: 900,
              color: "#111827",
            }}
          >
            ₹{Number(rent).toLocaleString()}
          </Typography>

          <Typography
            sx={{
              color: "#64748b",
              fontSize: 14,
            }}
          >
            / month
          </Typography>

        </Box>


        {/* AMENITIES */}
        <Stack
          direction="row"
          spacing={1}
          flexWrap="wrap"
          useFlexGap
          sx={{
            mb: 2,
          }}
        >

          {pg.wifiAvailable && (
            <Chip
              icon={<WifiRounded />}
              label="Wi-Fi"
              size="small"
              variant="outlined"
              sx={{
                borderRadius: 2,
                fontWeight: 600,
              }}
            />
          )}

          {pg.foodAvailable && (
            <Chip
              icon={<RestaurantRounded />}
              label="Food"
              size="small"
              variant="outlined"
              sx={{
                borderRadius: 2,
                fontWeight: 600,
              }}
            />
          )}

          {pg.parkingAvailable && (
            <Chip
              icon={<LocalParkingRounded />}
              label="Parking"
              size="small"
              variant="outlined"
              sx={{
                borderRadius: 2,
                fontWeight: 600,
              }}
            />
          )}

        </Stack>


        {/* AVAILABLE BEDS */}
        {pg.availableBeds !== undefined && (
          <Stack
            direction="row"
            alignItems="center"
            spacing={0.7}
            sx={{
              mb: 2,
              color: "#475569",
            }}
          >

            <KingBedRounded
              sx={{
                fontSize: 20,
                color: "#2563eb",
              }}
            />

            <Typography
              variant="body2"
              fontWeight={600}
            >
              {pg.availableBeds} beds available
            </Typography>

          </Stack>
        )}


        {/* BUTTON */}
        <Button
          fullWidth
          variant="contained"
          component={Link}
          to={`/pgs/${pg.id}`}
          endIcon={<ArrowForwardRounded />}
          sx={{
            mt: 0.5,
            py: 1.3,
            borderRadius: 2.5,
            textTransform: "none",
            fontSize: 15,
            fontWeight: 800,
            backgroundColor: "#2563eb",

            "&:hover": {
              backgroundColor: "#1d4ed8",
            },
          }}
        >
          View Details
        </Button>

      </CardContent>

    </Card>
  );
}