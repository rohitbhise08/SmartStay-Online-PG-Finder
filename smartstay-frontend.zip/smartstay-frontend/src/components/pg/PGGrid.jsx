import { Grid } from "@mui/material";
import PGCard from "./PGCard";
import EmptyState from "../common/EmptyState";

export default function PGGrid({ pgs = [] }) {

  if (!pgs.length) {
    return (
      <EmptyState
        title="No PGs found"
        text="Try another city, area or filter."
      />
    );
  }

  return (
    <Grid
      container
      spacing={3}
      justifyContent="flex-start"
      sx={{
        mt: 1
      }}
    >
      {pgs.map((pg) => (
        <Grid
          item
          key={pg.id}
          xs={12}
          sm={6}
          md={5}
          lg={4}
          xl={3}
        >
          <PGCard pg={pg} />
        </Grid>
      ))}
    </Grid>
  );
}