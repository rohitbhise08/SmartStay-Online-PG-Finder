import { MenuItem, Stack, TextField } from "@mui/material";

export default function PGFilter({ gender, setGender, city, setCity }) {
  return (
    <Stack direction={{ xs: "column", md: "row" }} spacing={2}>
      <TextField select fullWidth label="Gender" value={gender} onChange={(e) => setGender(e.target.value)}>
        <MenuItem value="">All</MenuItem>
        <MenuItem value="MALE">Male</MenuItem>
        <MenuItem value="FEMALE">Female</MenuItem>
        <MenuItem value="ANY">Any</MenuItem>
      </TextField>
      <TextField fullWidth label="City" value={city} onChange={(e) => setCity(e.target.value)} />
    </Stack>
  );
}
