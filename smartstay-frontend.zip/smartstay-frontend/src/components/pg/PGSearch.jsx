import { InputAdornment, TextField } from "@mui/material";
import { SearchRounded } from "@mui/icons-material";

export default function PGSearch({ value, onChange }) {
  return (
    <TextField
      fullWidth
      placeholder="Search by location, area or PG name..."
      value={value}
      onChange={(e) => onChange(e.target.value)}
      InputProps={{ startAdornment: <InputAdornment position="start"><SearchRounded /></InputAdornment> }}
    />
  );
}
