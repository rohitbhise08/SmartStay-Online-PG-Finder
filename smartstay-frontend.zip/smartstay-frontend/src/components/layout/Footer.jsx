import { Box, Container, Divider, Stack, Typography } from "@mui/material";
import {
  EmailRounded,
  LocationOnRounded,
  ArrowForwardRounded
} from "@mui/icons-material";
import { Link } from "react-router-dom";

export default function Footer() {
  return (
    <Box
      component="footer"
      sx={{
        bgcolor: "#101827",
        color: "#fff",
        mt: 8
      }}
    >

      <Container
        maxWidth="xl"
        sx={{
          py: { xs: 5, md: 7 }
        }}
      >

        {/* MAIN FOOTER */}

        <Box
          sx={{
            display: "grid",
            gridTemplateColumns: {
              xs: "1fr",
              sm: "1fr 1fr",
              md: "1.5fr 1fr 1fr 1fr"
            },
            gap: 5
          }}
        >

          {/* BRAND */}

          <Box>

            <Typography
              sx={{
                fontSize: 26,
                fontWeight: 900
              }}
            >
              SmartStay
            </Typography>

            <Typography
              sx={{
                color: "#aab4c4",
                mt: 1.5,
                maxWidth: 430,
                lineHeight: 1.7
              }}
            >
              Find comfortable, affordable PG
              accommodation and manage your
              bookings in one place.
            </Typography>

            <Typography
              sx={{
                color: "#64748b",
                mt: 2,
                fontSize: 13
              }}
            >
              Your trusted stay partner.
            </Typography>

          </Box>

          {/* EXPLORE */}

          <Box>

            <Typography
              fontWeight={800}
              sx={{ mb: 2 }}
            >
              Explore
            </Typography>

            <Typography
              component={Link}
              to="/"
              sx={{
                display: "block",
                color: "#aab4c4",
                mb: 1.2,
                "&:hover": {
                  color: "#fff"
                }
              }}
            >
              Home
            </Typography>

            <Typography
              component={Link}
              to="/pgs"
              sx={{
                display: "block",
                color: "#aab4c4",
                mb: 1.2,
                "&:hover": {
                  color: "#fff"
                }
              }}
            >
              Find a PG
            </Typography>

            <Typography
              component={Link}
              to="/#about"
              sx={{
                display: "block",
                color: "#aab4c4",
                mb: 1.2,
                "&:hover": {
                  color: "#fff"
                }
              }}
            >
              About
            </Typography>

            <Typography
              component={Link}
              to="/#contact"
              sx={{
                display: "block",
                color: "#aab4c4",
                "&:hover": {
                  color: "#fff"
                }
              }}
            >
              Contact
            </Typography>

          </Box>

          {/* ACCOUNT */}

          <Box>

            <Typography
              fontWeight={800}
              sx={{ mb: 2 }}
            >
              Account
            </Typography>

            <Typography
              component={Link}
              to="/login"
              sx={{
                display: "block",
                color: "#aab4c4",
                mb: 1.2,
                "&:hover": {
                  color: "#fff"
                }
              }}
            >
              Login
            </Typography>

            <Typography
              component={Link}
              to="/register"
              sx={{
                display: "block",
                color: "#aab4c4",
                mb: 1.2,
                "&:hover": {
                  color: "#fff"
                }
              }}
            >
              Register
            </Typography>

            <Typography
              component={Link}
              to="/bookings"
              sx={{
                display: "block",
                color: "#aab4c4",
                "&:hover": {
                  color: "#fff"
                }
              }}
            >
              My Bookings
            </Typography>

          </Box>

          {/* CONTACT */}

          <Box>

            <Typography
              fontWeight={800}
              sx={{ mb: 2 }}
            >
              Contact
            </Typography>

            <Stack
              direction="row"
              spacing={1}
              alignItems="center"
              sx={{ mb: 1.5 }}
            >

              <EmailRounded
                sx={{
                  fontSize: 19,
                  color: "#60a5fa"
                }}
              />

              <Typography
                sx={{
                  color: "#aab4c4"
                }}
              >
                support@smartstay.com
              </Typography>

            </Stack>

            <Stack
              direction="row"
              spacing={1}
              alignItems="center"
            >

              <LocationOnRounded
                sx={{
                  fontSize: 19,
                  color: "#60a5fa"
                }}
              />

              <Typography
                sx={{
                  color: "#aab4c4"
                }}
              >
                Mumbai, India
              </Typography>

            </Stack>

          </Box>

        </Box>

        {/* DIVIDER */}

        <Divider
          sx={{
            borderColor: "#293345",
            my: 4
          }}
        />

        {/* BOTTOM */}

        <Box
          sx={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            flexDirection: {
              xs: "column",
              sm: "row"
            },
            gap: 2
          }}
        >

          <Typography
            variant="body2"
            sx={{
              color: "#8995a7"
            }}
          >
            © {new Date().getFullYear()} SmartStay.
            All rights reserved.
          </Typography>

          <Typography
            variant="body2"
            sx={{
              color: "#64748b"
            }}
          >
            Find your perfect stay.
          </Typography>

        </Box>

      </Container>

    </Box>
  );
}