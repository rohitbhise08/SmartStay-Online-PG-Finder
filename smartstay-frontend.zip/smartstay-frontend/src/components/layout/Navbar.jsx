import { useState } from "react";
import {
  AppBar,
  Avatar,
  Box,
  Button,
  Drawer,
  IconButton,
  List,
  ListItemButton,
  ListItemText,
  Toolbar,
  Typography,
  useMediaQuery
} from "@mui/material";

import {
  MenuRounded,
  CloseRounded,
  SearchRounded,
  HomeRounded
} from "@mui/icons-material";

import { Link, useNavigate } from "react-router-dom";
import { useTheme } from "@mui/material/styles";
import { useAuth } from "../../context/AuthContext";

export default function Navbar() {

  const theme = useTheme();
  const mobile = useMediaQuery(theme.breakpoints.down("md"));

  const [open, setOpen] = useState(false);

  const {
    isAuthenticated,
    user,
    logout,
    isAdmin
  } = useAuth();

  const navigate = useNavigate();

  const links = [
    ["Home", "/"],
    ["PGs", "/pgs"]
  ];

  const go = (path) => {
    setOpen(false);
    navigate(path);
  };

  const goToSection = (section) => {
    setOpen(false);

    if (window.location.pathname !== "/") {
      navigate("/");

      setTimeout(() => {
        document
          .getElementById(section)
          ?.scrollIntoView({ behavior: "smooth" });
      }, 100);
    } else {
      document
        .getElementById(section)
        ?.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <AppBar
      position="sticky"
      elevation={0}
      sx={{
        bgcolor: "#ffffff",
        color: "#111827",
        borderBottom: "1px solid #e5e7eb",
        zIndex: 1000
      }}
    >

      <Toolbar
        sx={{
          minHeight: 78,
          px: { xs: 2, md: 5 },
          display: "flex",
          justifyContent: "space-between"
        }}
      >

        {/* LOGO */}
        <Box
          component={Link}
          to="/"
          sx={{
            display: "flex",
            alignItems: "center",
            gap: 1.2,
            textDecoration: "none",
            mr: { md: 5 }
          }}
        >

          {/* Logo Circle */}
          <Box
            sx={{
              width: 50,
              height: 50,
              borderRadius: "50%",
              bgcolor: "#2563eb",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              boxShadow: "0 6px 18px rgba(37,99,235,0.25)"
            }}
          >
            <HomeRounded
              sx={{
                color: "#fff",
                fontSize: 30
              }}
            />
          </Box>

          {/* Logo Text */}
          <Box>
            <Typography
              sx={{
                fontSize: { xs: 20, md: 25 },
                fontWeight: 900,
                lineHeight: 1,
                letterSpacing: "-0.8px",
                color: "#111827"
              }}
            >
              Smart
              <Box
                component="span"
                sx={{ color: "#2563eb" }}
              >
                Stay
              </Box>
            </Typography>

            <Typography
              sx={{
                fontSize: 9,
                fontWeight: 700,
                letterSpacing: 2.5,
                color: "#64748b",
                mt: 0.5
              }}
            >
              FIND • STAY • BELONG
            </Typography>
          </Box>

        </Box>


        {/* DESKTOP NAVIGATION */}
        {!mobile && (
          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              gap: 1,
              flex: 1
            }}
          >

            {links.map(([label, path]) => (
              <Button
                key={label}
                component={Link}
                to={path}
                color="inherit"
                sx={{
                  px: 2,
                  fontWeight: 700,
                  fontSize: 16,
                  textTransform: "none"
                }}
              >
                {label}
              </Button>
            ))}

            {/* ABOUT */}
            <Button
              onClick={() => goToSection("about")}
              color="inherit"
              sx={{
                px: 2,
                fontWeight: 700,
                fontSize: 16,
                textTransform: "none"
              }}
            >
              About
            </Button>

            {/* CONTACT */}
            <Button
              onClick={() => goToSection("contact")}
              color="inherit"
              sx={{
                px: 2,
                fontWeight: 700,
                fontSize: 16,
                textTransform: "none"
              }}
            >
              Contact
            </Button>

            {/* FIND PG */}
            <Button
              component={Link}
              to="/pgs"
              startIcon={<SearchRounded />}
              sx={{
                px: 2,
                fontWeight: 800,
                fontSize: 16,
                color: "#2563eb",
                textTransform: "none"
              }}
            >
              Find a PG
            </Button>

          </Box>
        )}


        {/* DESKTOP USER AREA */}
        {!mobile && (
          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              gap: 1
            }}
          >

            {isAuthenticated ? (
              <>
                <Button
                  component={Link}
                  to="/bookings"
                  sx={{ fontWeight: 700 }}
                >
                  My Bookings
                </Button>

                <Button
                  component={Link}
                  to="/profile"
                  sx={{ fontWeight: 700 }}
                >
                  Profile
                </Button>

                {isAdmin && (
                  <Button
                    component={Link}
                    to="/admin"
                    sx={{ fontWeight: 700 }}
                  >
                    Admin
                  </Button>
                )}

                <Button
                  variant="contained"
                  onClick={() => {
                    logout();
                    navigate("/");
                  }}
                  sx={{
                    borderRadius: 3,
                    px: 2.5,
                    fontWeight: 800,
                    textTransform: "none",
                    bgcolor: "#2563eb"
                  }}
                >
                  Logout
                </Button>

                <Avatar
                  sx={{
                    width: 38,
                    height: 38,
                    bgcolor: "#e8efff",
                    color: "#2563eb",
                    fontWeight: 800
                  }}
                >
                  {user?.fullName?.[0] || "U"}
                </Avatar>
              </>
            ) : (
              <>
                <Button
                  component={Link}
                  to="/login"
                  sx={{ fontWeight: 700 }}
                >
                  Login
                </Button>

                <Button
                  variant="contained"
                  component={Link}
                  to="/register"
                  sx={{
                    borderRadius: 3,
                    fontWeight: 800,
                    textTransform: "none"
                  }}
                >
                  Register
                </Button>
              </>
            )}

          </Box>
        )}


        {/* MOBILE MENU */}
        {mobile && (
          <IconButton
            onClick={() => setOpen(true)}
            sx={{ color: "#111827" }}
          >
            <MenuRounded />
          </IconButton>
        )}

      </Toolbar>


      {/* MOBILE DRAWER */}
      <Drawer
        anchor="right"
        open={open}
        onClose={() => setOpen(false)}
      >

        <Box sx={{ width: 280, p: 2 }}>

          <Box
            sx={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              mb: 2
            }}
          >

            <Typography
              fontWeight={900}
              fontSize={20}
            >
              Smart
              <Box
                component="span"
                sx={{ color: "#2563eb" }}
              >
                Stay
              </Box>
            </Typography>

            <IconButton
              onClick={() => setOpen(false)}
            >
              <CloseRounded />
            </IconButton>

          </Box>


          <List>

            <ListItemButton onClick={() => go("/")}>
              <ListItemText primary="Home" />
            </ListItemButton>

            <ListItemButton onClick={() => go("/pgs")}>
              <ListItemText primary="PGs" />
            </ListItemButton>

            <ListItemButton
              onClick={() => goToSection("about")}
            >
              <ListItemText primary="About" />
            </ListItemButton>

            <ListItemButton
              onClick={() => goToSection("contact")}
            >
              <ListItemText primary="Contact" />
            </ListItemButton>

            <ListItemButton
              onClick={() => go("/pgs")}
            >
              <ListItemText primary="Find a PG" />
            </ListItemButton>

            {isAuthenticated && (
              <ListItemButton
                onClick={() => go("/bookings")}
              >
                <ListItemText primary="My Bookings" />
              </ListItemButton>
            )}

            {isAuthenticated && (
              <ListItemButton
                onClick={() => go("/profile")}
              >
                <ListItemText primary="Profile" />
              </ListItemButton>
            )}

            {isAdmin && (
              <ListItemButton
                onClick={() => go("/admin")}
              >
                <ListItemText primary="Admin Dashboard" />
              </ListItemButton>
            )}

          </List>


          {isAuthenticated ? (

            <Button
              fullWidth
              variant="contained"
              onClick={() => {
                logout();
                go("/");
              }}
            >
              Logout
            </Button>

          ) : (

            <Box
              sx={{
                display: "grid",
                gap: 1
              }}
            >

              <Button
                fullWidth
                onClick={() => go("/login")}
              >
                Login
              </Button>

              <Button
                fullWidth
                variant="contained"
                onClick={() => go("/register")}
              >
                Register
              </Button>

            </Box>

          )}

        </Box>

      </Drawer>

    </AppBar>
  );
}