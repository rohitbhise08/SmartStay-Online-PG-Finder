import {
  Box,
  Button,
  Card,
  CardContent,
  Chip,
  Divider,
  Stack,
  Typography
} from "@mui/material";

import {
  EventAvailableRounded,
  KingBedRounded,
  ArrowForwardRounded
} from "@mui/icons-material";

import { Link } from "react-router-dom";

export default function BookingCard({ booking }) {

  const status =
    booking.bookingStatus ||
    booking.status ||
    "PENDING";

  const statusColor =
    status === "CONFIRMED"
      ? "success"
      : status === "CANCELLED"
      ? "error"
      : "warning";

  return (
    <Card
      sx={{
        height: "100%",
        border: "1px solid #e5e7eb",
        borderRadius: 3,
        transition: "0.3s",
        "&:hover": {
          transform: "translateY(-4px)",
          boxShadow: "0 10px 25px rgba(0,0,0,0.08)"
        }
      }}
    >

      <CardContent sx={{ p: 2.5 }}>

        {/* HEADER */}

        <Stack
          direction="row"
          justifyContent="space-between"
          alignItems="center"
          gap={1}
        >

          <Typography
            variant="h6"
            fontWeight={900}
          >
            Booking #{booking.id}
          </Typography>

          <Chip
            label={String(status).replaceAll("_", " ")}
            color={statusColor}
            size="small"
          />

        </Stack>

        {/* PG */}

        <Typography
          sx={{
            mt: 2,
            fontSize: 17,
            fontWeight: 800
          }}
        >
          PG ID: {booking.pgId}
        </Typography>

        <Divider sx={{ my: 2 }} />

        {/* BOOKING DETAILS */}

        <Stack spacing={1.5}>

          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              gap: 1
            }}
          >

            <EventAvailableRounded
              color="primary"
              fontSize="small"
            />

            <Box>
              <Typography
                fontSize={12}
                color="text.secondary"
              >
                Check-in
              </Typography>

              <Typography fontWeight={700}>
                {booking.checkInDate || "-"}
              </Typography>
            </Box>

          </Box>

          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              gap: 1
            }}
          >

            <EventAvailableRounded
              color="primary"
              fontSize="small"
            />

            <Box>
              <Typography
                fontSize={12}
                color="text.secondary"
              >
                Check-out
              </Typography>

              <Typography fontWeight={700}>
                {booking.checkOutDate || "-"}
              </Typography>
            </Box>

          </Box>

          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              gap: 1
            }}
          >

            <KingBedRounded
              color="primary"
              fontSize="small"
            />

            <Box>
              <Typography
                fontSize={12}
                color="text.secondary"
              >
                Number of Beds
              </Typography>

              <Typography fontWeight={700}>
                {booking.numberOfBeds || 0} bed(s)
              </Typography>
            </Box>

          </Box>

        </Stack>

        {/* BUTTON */}

        <Button
          fullWidth
          component={Link}
          to={`/bookings/${booking.id}`}
          variant="contained"
          endIcon={<ArrowForwardRounded />}
          sx={{
            mt: 3,
            py: 1.2,
            borderRadius: 2,
            fontWeight: 800,
            textTransform: "none"
          }}
        >
          View Booking
        </Button>

      </CardContent>

    </Card>
  );
}