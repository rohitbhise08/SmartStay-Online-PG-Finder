import { useState } from "react";
import { Button, Card, CardContent, Grid, MenuItem, TextField, Typography } from "@mui/material";

export default function BookingForm({ pg, onSubmit, loading }) {
  const [form, setForm] = useState({ checkInDate:"", checkOutDate:"", numberOfBeds:1, specialRequest:"" });
  const update=e=>setForm(f=>({...f,[e.target.name]:e.target.value}));
  return <Card><CardContent sx={{p:{xs:2,md:4}}}>
    <Typography variant="h5" fontWeight={900} sx={{mb:3}}>Booking Details</Typography>
    <Grid container spacing={2}>
      <Grid item xs={12}><TextField fullWidth label="PG Name" value={pg?.name||""} InputProps={{readOnly:true}}/></Grid>
      <Grid item xs={12} md={6}><TextField fullWidth type="date" label="Check-in Date" name="checkInDate" value={form.checkInDate} onChange={update} InputLabelProps={{shrink:true}} required/></Grid>
      <Grid item xs={12} md={6}><TextField fullWidth type="date" label="Check-out Date" name="checkOutDate" value={form.checkOutDate} onChange={update} InputLabelProps={{shrink:true}}/></Grid>
      <Grid item xs={12}><TextField select fullWidth label="Number of Beds" name="numberOfBeds" value={form.numberOfBeds} onChange={update}>
        {Array.from({length:Math.max(1,Math.min(10,pg?.availableBeds||1))},(_,i)=><MenuItem key={i+1} value={i+1}>{i+1}</MenuItem>)}
      </TextField></Grid>
      <Grid item xs={12}><TextField fullWidth multiline minRows={3} label="Special Request" name="specialRequest" value={form.specialRequest} onChange={update}/></Grid>
      <Grid item xs={12}><Button fullWidth variant="contained" size="large" onClick={()=>onSubmit(form)} disabled={loading}>{loading?"Confirming...":"Confirm Booking"}</Button></Grid>
    </Grid>
  </CardContent></Card>;
}
