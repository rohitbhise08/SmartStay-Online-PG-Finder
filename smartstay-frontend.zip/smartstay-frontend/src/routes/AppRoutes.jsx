import { Routes, Route } from "react-router-dom";
import MainLayout from "../components/layout/MainLayout";
import Home from "../features/home/Home";
import Login from "../features/auth/Login";
import Register from "../features/auth/Register";
import ForgotPassword from "../features/auth/ForgotPassword";
import PGList from "../features/pg/PGList";
import PGDetails from "../features/pg/PGDetails";
import AddPG from "../features/pg/AddPG";
import EditPG from "../features/pg/EditPG";
import MyPGs from "../features/pg/MyPGs";
import Booking from "../features/booking/Booking";
import MyBookings from "../features/booking/MyBookings";
import BookingDetails from "../features/booking/BookingDetails";
import Reviews from "../features/review/Reviews";
import Profile from "../features/profile/Profile";
import AdminDashboard from "../features/admin/AdminDashboard";
import ManageUsers from "../features/admin/ManageUsers";
import ManagePGs from "../features/admin/ManagePGs";
import ManageBookings from "../features/admin/ManageBookings";
import ProtectedRoute from "./ProtectedRoute";
import AdminRoute from "./AdminRoute";

export default function AppRoutes(){
 return <Routes>
  <Route element={<MainLayout/>}>
   <Route path="/" element={<Home/>}/>
   <Route path="/login" element={<Login/>}/>
   <Route path="/register" element={<Register/>}/>
   <Route path="/forgot-password" element={<ForgotPassword/>}/>
   <Route path="/pgs" element={<PGList/>}/>
   <Route path="/pgs/:id" element={<PGDetails/>}/>
   <Route element={<ProtectedRoute/>}>
    <Route path="/pgs/add" element={<AddPG/>}/>
    <Route path="/pgs/edit/:id" element={<EditPG/>}/>
    <Route path="/my-pgs" element={<MyPGs/>}/>
    <Route path="/bookings/new" element={<Booking/>}/>
    <Route path="/bookings" element={<MyBookings/>}/>
    <Route path="/bookings/:id" element={<BookingDetails/>}/>
    <Route path="/reviews" element={<Reviews/>}/>
    <Route path="/profile" element={<Profile/>}/>
   </Route>
   <Route element={<AdminRoute/>}>
    <Route path="/admin" element={<AdminDashboard/>}/>
    <Route path="/admin/users" element={<ManageUsers/>}/>
    <Route path="/admin/pgs" element={<ManagePGs/>}/>
    <Route path="/admin/bookings" element={<ManageBookings/>}/>
   </Route>
  </Route>
 </Routes>;
}
