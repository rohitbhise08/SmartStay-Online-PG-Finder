import { useState } from "react";
import {
  Alert,
  Box,
  Button,
  Card,
  CardContent,
  Container,
  Divider,
  TextField,
  Typography
} from "@mui/material";

import {
  LoginRounded,
  SecurityRounded
} from "@mui/icons-material";

import {
  Link,
  useLocation,
  useNavigate
} from "react-router-dom";

import { useAuth } from "../../context/AuthContext";

export default function Login() {

  const { login } = useAuth();

  const navigate = useNavigate();
  const location = useLocation();

  const [form, setForm] = useState({
    email: "",
    password: ""
  });

  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async (e) => {

    e.preventDefault();

    setError("");
    setLoading(true);

    try {

      await login(form);

      navigate(
        location.state?.from || "/"
      );

    } catch (err) {

      setError(
        err?.response?.data?.message ||
        err?.response?.data?.error ||
        "Invalid email or password."
      );

    } finally {

      setLoading(false);

    }
  };

  return (
    <Box
      sx={{
        minHeight: "calc(100vh - 74px)",
        bgcolor: "#f8fafc",
        display: "flex",
        alignItems: "center",
        py: { xs: 5, md: 8 }
      }}
    >

      <Container maxWidth="sm">

        <Card
          elevation={0}
          sx={{
            borderRadius: 4,
            border: "1px solid #e5e7eb",
            boxShadow:
              "0 15px 40px rgba(15,23,42,0.08)"
          }}
        >

          <CardContent
            sx={{
              p: { xs: 3, md: 5 }
            }}
          >

            {/* HEADER */}

            <Box
              sx={{
                textAlign: "center",
                mb: 4
              }}
            >

              <Box
                sx={{
                  width: 58,
                  height: 58,
                  borderRadius: 3,
                  bgcolor: "#eff6ff",
                  color: "primary.main",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  mx: "auto",
                  mb: 2
                }}
              >
                <LoginRounded fontSize="large" />
              </Box>

              <Typography
                sx={{
                  fontSize: {
                    xs: 30,
                    md: 36
                  },
                  fontWeight: 900
                }}
              >
                Welcome Back!
              </Typography>

              <Typography
                color="text.secondary"
                sx={{ mt: 1 }}
              >
                Login to your SmartStay account
              </Typography>

            </Box>

            {/* ERROR */}

            {error && (
              <Alert
                severity="error"
                sx={{
                  mb: 2,
                  borderRadius: 2
                }}
              >
                {error}
              </Alert>
            )}

            {/* FORM */}

            <Box
              component="form"
              onSubmit={submit}
              sx={{
                display: "grid",
                gap: 2
              }}
            >

              <TextField
                fullWidth
                label="Email Address"
                name="email"
                type="email"
                value={form.email}
                onChange={(e) =>
                  setForm({
                    ...form,
                    email: e.target.value
                  })
                }
                required
              />

              <TextField
                fullWidth
                label="Password"
                name="password"
                type="password"
                value={form.password}
                onChange={(e) =>
                  setForm({
                    ...form,
                    password: e.target.value
                  })
                }
                required
              />

              <Box
                sx={{
                  textAlign: "right",
                  mt: -0.5
                }}
              >
                <Typography
                  component={Link}
                  to="/forgot-password"
                  sx={{
                    color: "primary.main",
                    fontSize: 14,
                    fontWeight: 700
                  }}
                >
                  Forgot Password?
                </Typography>
              </Box>

              <Button
                type="submit"
                variant="contained"
                size="large"
                disabled={loading}
                sx={{
                  mt: 1,
                  py: 1.4,
                  borderRadius: 2.5,
                  fontWeight: 800,
                  textTransform: "none",
                  fontSize: 16
                }}
              >
                {loading
                  ? "Logging in..."
                  : "Login"}
              </Button>

            </Box>

            <Divider sx={{ my: 3 }}>
              <Typography
                color="text.secondary"
                fontSize={13}
              >
                OR
              </Typography>
            </Divider>

            {/* REGISTER */}

            <Typography
              textAlign="center"
              color="text.secondary"
            >
              Don't have an account?{" "}

              <Typography
                component={Link}
                to="/register"
                sx={{
                  color: "primary.main",
                  fontWeight: 800,
                  cursor: "pointer"
                }}
              >
                Register here
              </Typography>
            </Typography>

            {/* SECURITY */}

            <Box
              sx={{
                mt: 3,
                p: 1.5,
                borderRadius: 2,
                bgcolor: "#f8fafc",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                gap: 1
              }}
            >

              <SecurityRounded
                sx={{
                  fontSize: 18,
                  color: "success.main"
                }}
              />

              <Typography
                fontSize={12}
                color="text.secondary"
              >
                Your account information is secure
              </Typography>

            </Box>

          </CardContent>

        </Card>

      </Container>

    </Box>
  );
}