import { useState } from "react";
import {
  Alert,
  Box,
  Button,
  Card,
  CardContent,
  Container,
  Divider,
  MenuItem,
  TextField,
  Typography
} from "@mui/material";

import {
  PersonAddRounded,
  SecurityRounded
} from "@mui/icons-material";

import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";

export default function Register() {

  const { register } = useAuth();
  const navigate = useNavigate();

  const [form, setForm] = useState({
    fullName: "",
    email: "",
    password: "",
    phone: "",
    role: "ROLE_USER"
  });

  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async (e) => {

    e.preventDefault();
    setError("");

    if (form.password !== confirm) {
      setError("Passwords do not match.");
      return;
    }

    setLoading(true);

    try {

      await register(form);

      navigate("/login");

    } catch (err) {

      setError(
        err?.response?.data?.message ||
        err?.response?.data?.error ||
        "Registration failed."
      );

    } finally {

      setLoading(false);

    }
  };

  return (
    <Box
      sx={{
        minHeight: "calc(100vh - 74px)",
        bgcolor: "#f8fafc",
        display: "flex",
        alignItems: "center",
        py: { xs: 5, md: 7 }
      }}
    >

      <Container maxWidth="sm">

        <Card
          elevation={0}
          sx={{
            borderRadius: 4,
            border: "1px solid #e5e7eb",
            boxShadow:
              "0 15px 40px rgba(15,23,42,0.08)"
          }}
        >

          <CardContent
            sx={{
              p: { xs: 3, md: 5 }
            }}
          >

            {/* HEADER */}

            <Box
              sx={{
                textAlign: "center",
                mb: 4
              }}
            >

              <Box
                sx={{
                  width: 58,
                  height: 58,
                  borderRadius: 3,
                  bgcolor: "#eff6ff",
                  color: "primary.main",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  mx: "auto",
                  mb: 2
                }}
              >
                <PersonAddRounded fontSize="large" />
              </Box>

              <Typography
                sx={{
                  fontSize: {
                    xs: 30,
                    md: 36
                  },
                  fontWeight: 900
                }}
              >
                Create Account
              </Typography>

              <Typography
                color="text.secondary"
                sx={{ mt: 1 }}
              >
                Join SmartStay and find your perfect stay
              </Typography>

            </Box>

            {/* ERROR */}

            {error && (
              <Alert
                severity="error"
                sx={{
                  mb: 2,
                  borderRadius: 2
                }}
              >
                {error}
              </Alert>
            )}

            {/* FORM */}

            <Box
              component="form"
              onSubmit={submit}
              sx={{
                display: "grid",
                gap: 2
              }}
            >

              <TextField
                fullWidth
                label="Full Name"
                value={form.fullName}
                onChange={(e) =>
                  setForm({
                    ...form,
                    fullName: e.target.value
                  })
                }
                required
              />

              <Box
                sx={{
                  display: "grid",
                  gridTemplateColumns: {
                    xs: "1fr",
                    sm: "1fr 1fr"
                  },
                  gap: 2
                }}
              >

                <TextField
                  fullWidth
                  label="Email Address"
                  type="email"
                  value={form.email}
                  onChange={(e) =>
                    setForm({
                      ...form,
                      email: e.target.value
                    })
                  }
                  required
                />

                <TextField
                  fullWidth
                  label="Phone Number"
                  value={form.phone}
                  onChange={(e) =>
                    setForm({
                      ...form,
                      phone: e.target.value
                    })
                  }
                  required
                />

              </Box>

              <Box
                sx={{
                  display: "grid",
                  gridTemplateColumns: {
                    xs: "1fr",
                    sm: "1fr 1fr"
                  },
                  gap: 2
                }}
              >

                <TextField
                  fullWidth
                  label="Password"
                  type="password"
                  value={form.password}
                  onChange={(e) =>
                    setForm({
                      ...form,
                      password: e.target.value
                    })
                  }
                  required
                />

                <TextField
                  fullWidth
                  label="Confirm Password"
                  type="password"
                  value={confirm}
                  onChange={(e) =>
                    setConfirm(e.target.value)
                  }
                  required
                />

              </Box>

              <TextField
                fullWidth
                select
                label="Account Type"
                value={form.role}
                onChange={(e) =>
                  setForm({
                    ...form,
                    role: e.target.value
                  })
                }
              >

                <MenuItem value="ROLE_USER">
                  User
                </MenuItem>

                <MenuItem value="ROLE_OWNER">
                  PG Owner
                </MenuItem>

              </TextField>

              <Button
                fullWidth
                size="large"
                type="submit"
                variant="contained"
                disabled={loading}
                sx={{
                  mt: 1,
                  py: 1.4,
                  borderRadius: 2.5,
                  fontWeight: 800,
                  textTransform: "none",
                  fontSize: 16
                }}
              >
                {loading
                  ? "Creating Account..."
                  : "Create Account"}
              </Button>

            </Box>

            <Divider sx={{ my: 3 }}>
              <Typography
                color="text.secondary"
                fontSize={13}
              >
                ALREADY A MEMBER?
              </Typography>
            </Divider>

            {/* LOGIN */}

            <Typography
              textAlign="center"
              color="text.secondary"
            >
              Already have an account?{" "}

              <Typography
                component={Link}
                to="/login"
                sx={{
                  color: "primary.main",
                  fontWeight: 800
                }}
              >
                Login here
              </Typography>

            </Typography>

            {/* SECURITY */}

            <Box
              sx={{
                mt: 3,
                p: 1.5,
                borderRadius: 2,
                bgcolor: "#f8fafc",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                gap: 1
              }}
            >

              <SecurityRounded
                sx={{
                  fontSize: 18,
                  color: "success.main"
                }}
              />

              <Typography
                fontSize={12}
                color="text.secondary"
              >
                Your account information is secure
              </Typography>

            </Box>

          </CardContent>

        </Card>

      </Container>

    </Box>
  );
}