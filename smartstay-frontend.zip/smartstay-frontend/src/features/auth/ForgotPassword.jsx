import { useState } from "react";
import { Alert, Box, Button, Card, CardContent, Container, TextField, Typography } from "@mui/material";
import { Link } from "react-router-dom";

export default function ForgotPassword() {
  const [sent, setSent] = useState(false);
  return <Container maxWidth="sm" sx={{py:8}}>
    <Card><CardContent sx={{p:{xs:3,md:5}}}>
      <Typography variant="h4" fontWeight={900} textAlign="center">Forgot Password?</Typography>
      <Typography color="text.secondary" textAlign="center" sx={{mt:1,mb:3}}>Enter your email to request a password reset.</Typography>
      {sent && <Alert severity="info" sx={{mb:2}}>Password reset workflow is not implemented in the current backend contract. Connect the backend reset endpoint before enabling this form.</Alert>}
      <Box sx={{display:"grid",gap:2}}>
        <TextField label="Email" type="email" required />
        <Button variant="contained" onClick={()=>setSent(true)}>Send Request</Button>
        <Button component={Link} to="/login">Back to Login</Button>
      </Box>
    </CardContent></Card>
  </Container>;
}
