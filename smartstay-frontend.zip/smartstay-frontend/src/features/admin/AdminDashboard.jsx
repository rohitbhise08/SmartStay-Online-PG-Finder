import { useEffect, useState } from "react";
import { Card, CardContent, Container, Grid, Typography } from "@mui/material";
import axios from "../../api/axiosInstance";
import { API } from "../../api/apiEndpoints";

function countResult(result) {
  if (result.status !== "fulfilled") return 0;
  const d = result.value?.data;
  if (Array.isArray(d)) return d.length;
  if (Array.isArray(d?.data)) return d.data.length;
  if (Array.isArray(d?.content)) return d.content.length;
  return 0;
}

export default function AdminDashboard() {
  const [stats, setStats] = useState({ pgs: 0, bookings: 0, users: 0, reviews: 0 });

  useEffect(() => {
    Promise.allSettled([
      axios.get(API.PGS.BASE),
      axios.get(API.BOOKINGS.BASE),
      axios.get(API.USERS.BASE),
      axios.get(API.REVIEWS.BASE),
    ]).then((rs) =>
      setStats({
        pgs: countResult(rs[0]),
        bookings: countResult(rs[1]),
        users: countResult(rs[2]),
        reviews: countResult(rs[3]),
      })
    );
  }, []);

  return (
    <Container maxWidth="xl" sx={{ py: 5 }}>
      <Typography variant="h3">Admin Dashboard</Typography>
      <Typography color="text.secondary" sx={{ mb: 3 }}>
        Overview of SmartStay.
      </Typography>
      <Grid container spacing={3}>
        {Object.entries(stats).map(([k, v]) => (
          <Grid item xs={12} sm={6} md={3} key={k}>
            <Card>
              <CardContent>
                <Typography color="text.secondary">{k.toUpperCase()}</Typography>
                <Typography variant="h3" fontWeight={900}>{v}</Typography>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>
    </Container>
  );
}
