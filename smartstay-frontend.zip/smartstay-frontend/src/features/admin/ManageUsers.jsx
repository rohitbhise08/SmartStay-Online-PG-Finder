import { useEffect, useState } from "react";
import { Container, Paper, Table, TableBody, TableCell, TableHead, TableRow, Typography } from "@mui/material";
import axios from "../../api/axiosInstance";
import { API } from "../../api/apiEndpoints";
export default function ManageUsers(){const [data,setData]=useState([]);useEffect(()=>{axios.get(API.USERS.BASE).then(r=>{const d=r.data;setData(Array.isArray(d)?d:(d?.data||[]))})},[]);return <Container maxWidth="xl" sx={{py:5}}><Typography variant="h3">User Management</Typography><Paper sx={{mt:3,overflowX:"auto"}}><Table><TableHead><TableRow><TableCell>ID</TableCell><TableCell>Name</TableCell><TableCell>Email</TableCell><TableCell>Role</TableCell></TableRow></TableHead><TableBody>{data.map(u=><TableRow key={u.id}><TableCell>{u.id}</TableCell><TableCell>{u.fullName||u.name}</TableCell><TableCell>{u.email}</TableCell><TableCell>{u.role?.roleName||u.role}</TableCell></TableRow>)}</TableBody></Table></Paper></Container>}
