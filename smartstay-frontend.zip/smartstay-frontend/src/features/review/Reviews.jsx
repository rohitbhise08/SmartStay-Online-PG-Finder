import { useEffect, useState } from "react";
import { Alert, Button, Container, Rating, Stack, TextField, Typography, Paper } from "@mui/material";
import { useSearchParams } from "react-router-dom";
import axios from "../../api/axiosInstance";
import { API } from "../../api/apiEndpoints";
import { useAuth } from "../../context/AuthContext";

export default function Reviews(){
 const [params]=useSearchParams();const pgId=params.get("pgId");const {user}=useAuth();const [reviews,setReviews]=useState([]),[rating,setRating]=useState(5),[comment,setComment]=useState(""),[error,setError]=useState("");
 const load=()=>pgId&&axios.get(API.REVIEWS.BY_PG(pgId)).then(r=>{const d=r.data;setReviews(Array.isArray(d)?d:(d?.data||[]))}).catch(setError);
 useEffect(load,[pgId]);
 const submit=async()=>{try{await axios.post(API.REVIEWS.BASE,{pgId:Number(pgId),userId:user?.id,rating,comment});setComment("");load()}catch(e){setError(e)}};
 return <Container maxWidth="md" sx={{py:5}}><Typography variant="h3">Reviews</Typography>{error&&<Alert severity="error" sx={{my:2}}>Unable to load or submit review.</Alert>}<Paper sx={{p:3,my:3}}><Typography fontWeight={800}>Write a Review</Typography><Rating value={rating} onChange={(_,v)=>setRating(v||5)} sx={{my:1}}/><TextField fullWidth multiline minRows={3} label="Your review" value={comment} onChange={e=>setComment(e.target.value)}/><Button variant="contained" sx={{mt:2}} onClick={submit}>Submit Review</Button></Paper><Stack spacing={2}>{reviews.map(r=><Paper sx={{p:3}} key={r.id}><Rating readOnly value={Number(r.rating)||0}/><Typography sx={{mt:1}}>{r.comment}</Typography></Paper>)}</Stack></Container>;
}
