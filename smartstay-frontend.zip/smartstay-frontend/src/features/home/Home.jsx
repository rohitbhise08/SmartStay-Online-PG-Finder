import { useEffect } from "react";
import {
  Box,
  Button,
  Card,
  CardContent,
  Container,
  Grid,
  Stack,
  TextField,
  Typography,
} from "@mui/material";

import {
  SearchRounded,
  VerifiedRounded,
  LocationOnRounded,
  EventAvailableRounded,
  SupportAgentRounded,
  ArrowForwardRounded,
} from "@mui/icons-material";

import { useLocation, useNavigate } from "react-router-dom";

const heroImage =
  "https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=1800&q=85";

export default function Home() {
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    if (location.hash) {
      const section = document.getElementById(
        location.hash.substring(1)
      );

      if (section) {
        setTimeout(() => {
          section.scrollIntoView({
            behavior: "smooth",
            block: "start",
          });
        }, 100);
      }
    }
  }, [location]);

  const goToSection = (section) => {
    navigate(`/#${section}`);

    setTimeout(() => {
      document.getElementById(section)?.scrollIntoView({
        behavior: "smooth",
        block: "start",
      });
    }, 100);
  };

  return (
    <Box sx={{ bgcolor: "#f7f9fc" }}>

      {/* HERO */}

      <Box
        sx={{
          position: "relative",
          minHeight: { xs: 700, md: 760 },
          display: "flex",
          alignItems: "center",
          overflow: "hidden",
          backgroundImage: `url(${heroImage})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      >
        <Box
          sx={{
            position: "absolute",
            inset: 0,
            background:
              "linear-gradient(90deg, rgba(7,18,42,0.92), rgba(7,18,42,0.65), rgba(7,18,42,0.20))",
          }}
        />

        <Container
          maxWidth="xl"
          sx={{
            position: "relative",
            zIndex: 2,
            py: 8,
          }}
        >
          <Grid container>
            <Grid item xs={12} md={8} lg={7}>

              <Box
                sx={{
                  display: "inline-flex",
                  alignItems: "center",
                  gap: 1,
                  px: 2,
                  py: 1,
                  mb: 3,
                  borderRadius: 10,
                  border: "1px solid rgba(255,255,255,0.35)",
                  bgcolor: "rgba(255,255,255,0.10)",
                }}
              >
                <VerifiedRounded sx={{ color: "#60a5fa" }} />

                <Typography
                  sx={{
                    color: "#fff",
                    fontWeight: 700,
                    fontSize: 14,
                  }}
                >
                  VERIFIED PGs • EASY BOOKING
                </Typography>
              </Box>

              <Typography
                component="h1"
                sx={{
                  color: "#fff",
                  fontWeight: 900,
                  fontSize: {
                    xs: 48,
                    sm: 62,
                    md: 76,
                  },
                  lineHeight: 1.03,
                  letterSpacing: "-2px",
                }}
              >
                Find a place
                <br />
                <Box
                  component="span"
                  sx={{ color: "#4f8df7" }}
                >
                  that feels like
                </Box>
                <br />
                home.
              </Typography>

              <Typography
                sx={{
                  mt: 3,
                  color: "rgba(255,255,255,0.88)",
                  fontSize: { xs: 17, md: 20 },
                  lineHeight: 1.7,
                  maxWidth: 700,
                }}
              >
                Discover comfortable, affordable and verified
                PG accommodations for students and working
                professionals.
              </Typography>

              <Box
                sx={{
                  mt: 4,
                  width: "100%",
                  maxWidth: 760,
                  p: 0.7,
                  display: "flex",
                  alignItems: "center",
                  bgcolor: "#fff",
                  borderRadius: 4,
                  gap: 1,
                }}
              >
                <SearchRounded
                  sx={{
                    ml: 1.5,
                    color: "#64748b",
                  }}
                />

                <TextField
                  fullWidth
                  placeholder="Search by location, area or PG name..."
                  variant="standard"
                  InputProps={{
                    disableUnderline: true,
                  }}
                  sx={{
                    "& input": {
                      py: 1.3,
                      fontSize: 16,
                    },
                  }}
                />

                <Button
                  variant="contained"
                  onClick={() => navigate("/pgs")}
                  startIcon={<SearchRounded />}
                  sx={{
                    minWidth: 145,
                    height: 54,
                    borderRadius: 3,
                    bgcolor: "#2563eb",
                    fontWeight: 800,
                    textTransform: "none",
                    fontSize: 16,
                    boxShadow: "none",
                    "&:hover": {
                      bgcolor: "#1d4ed8",
                    },
                  }}
                >
                  Search
                </Button>
              </Box>

              <Stack
                direction="row"
                spacing={6}
                sx={{
                  mt: 5,
                  flexWrap: "wrap",
                  rowGap: 2,
                }}
              >
                <Box>
                  <Typography
                    sx={{
                      color: "#fff",
                      fontWeight: 900,
                      fontSize: 30,
                    }}
                  >
                    500+
                  </Typography>

                  <Typography
                    sx={{
                      color: "rgba(255,255,255,0.70)",
                    }}
                  >
                    PGs Available
                  </Typography>
                </Box>

                <Box>
                  <Typography
                    sx={{
                      color: "#fff",
                      fontWeight: 900,
                      fontSize: 30,
                    }}
                  >
                    1,000+
                  </Typography>

                  <Typography
                    sx={{
                      color: "rgba(255,255,255,0.70)",
                    }}
                  >
                    Happy Customers
                  </Typography>
                </Box>

                <Box>
                  <Typography
                    sx={{
                      color: "#fff",
                      fontWeight: 900,
                      fontSize: 30,
                    }}
                  >
                    4.5★
                  </Typography>

                  <Typography
                    sx={{
                      color: "rgba(255,255,255,0.70)",
                    }}
                  >
                    Average Rating
                  </Typography>
                </Box>
              </Stack>

            </Grid>
          </Grid>
        </Container>
      </Box>


      {/* ABOUT */}

      <Box
        id="about"
        sx={{
          py: { xs: 8, md: 11 },
          bgcolor: "#fff",
          scrollMarginTop: "80px",
        }}
      >
        <Container maxWidth="xl">

          <Box
            sx={{
              textAlign: "center",
              maxWidth: 750,
              mx: "auto",
              mb: 6,
            }}
          >
            <Typography
              sx={{
                color: "#2563eb",
                fontWeight: 800,
                fontSize: 15,
                letterSpacing: 1.5,
              }}
            >
              WHY SMARTSTAY
            </Typography>

            <Typography
              component="h2"
              sx={{
                mt: 1,
                fontWeight: 900,
                color: "#111827",
                fontSize: { xs: 38, md: 52 },
              }}
            >
              Stay with confidence
            </Typography>

            <Typography
              sx={{
                mt: 2,
                color: "#64748b",
                fontSize: 18,
              }}
            >
              Everything you need to find a comfortable,
              secure and suitable place to stay.
            </Typography>
          </Box>

          <Grid container spacing={3}>

            <Grid item xs={12} sm={6} lg={3}>
              <Card
                elevation={0}
                sx={{
                  height: "100%",
                  p: 2,
                  border: "1px solid #e5eaf2",
                  borderRadius: 4,
                  "&:hover": {
                    transform: "translateY(-5px)",
                    boxShadow: "0 18px 40px rgba(15,23,42,0.08)",
                  },
                }}
              >
                <CardContent>
                  <Box
                    sx={{
                      width: 58,
                      height: 58,
                      borderRadius: 3,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      bgcolor: "#eaf2ff",
                      mb: 3,
                    }}
                  >
                    <VerifiedRounded
                      sx={{
                        color: "#2563eb",
                        fontSize: 30,
                      }}
                    />
                  </Box>

                  <Typography variant="h6" fontWeight={800}>
                    Verified PGs
                  </Typography>

                  <Typography
                    sx={{
                      mt: 1,
                      color: "#64748b",
                      lineHeight: 1.7,
                    }}
                  >
                    Find quality accommodations with
                    trusted property details.
                  </Typography>
                </CardContent>
              </Card>
            </Grid>


            <Grid item xs={12} sm={6} lg={3}>
              <Card
                elevation={0}
                sx={{
                  height: "100%",
                  p: 2,
                  border: "1px solid #e5eaf2",
                  borderRadius: 4,
                  "&:hover": {
                    transform: "translateY(-5px)",
                    boxShadow: "0 18px 40px rgba(15,23,42,0.08)",
                  },
                }}
              >
                <CardContent>
                  <Box
                    sx={{
                      width: 58,
                      height: 58,
                      borderRadius: 3,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      bgcolor: "#eaf2ff",
                      mb: 3,
                    }}
                  >
                    <LocationOnRounded
                      sx={{
                        color: "#2563eb",
                        fontSize: 30,
                      }}
                    />
                  </Box>

                  <Typography variant="h6" fontWeight={800}>
                    Prime Locations
                  </Typography>

                  <Typography
                    sx={{
                      mt: 1,
                      color: "#64748b",
                      lineHeight: 1.7,
                    }}
                  >
                    Discover PGs close to colleges,
                    offices and everyday essentials.
                  </Typography>
                </CardContent>
              </Card>
            </Grid>


            <Grid item xs={12} sm={6} lg={3}>
              <Card
                elevation={0}
                sx={{
                  height: "100%",
                  p: 2,
                  border: "1px solid #e5eaf2",
                  borderRadius: 4,
                  "&:hover": {
                    transform: "translateY(-5px)",
                    boxShadow: "0 18px 40px rgba(15,23,42,0.08)",
                  },
                }}
              >
                <CardContent>
                  <Box
                    sx={{
                      width: 58,
                      height: 58,
                      borderRadius: 3,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      bgcolor: "#eaf2ff",
                      mb: 3,
                    }}
                  >
                    <EventAvailableRounded
                      sx={{
                        color: "#2563eb",
                        fontSize: 30,
                      }}
                    />
                  </Box>

                  <Typography variant="h6" fontWeight={800}>
                    Easy Booking
                  </Typography>

                  <Typography
                    sx={{
                      mt: 1,
                      color: "#64748b",
                      lineHeight: 1.7,
                    }}
                  >
                    Search, compare and book your PG
                    in just a few clicks.
                  </Typography>
                </CardContent>
              </Card>
            </Grid>


            <Grid item xs={12} sm={6} lg={3}>
              <Card
                elevation={0}
                sx={{
                  height: "100%",
                  p: 2,
                  border: "1px solid #e5eaf2",
                  borderRadius: 4,
                  "&:hover": {
                    transform: "translateY(-5px)",
                    boxShadow: "0 18px 40px rgba(15,23,42,0.08)",
                  },
                }}
              >
                <CardContent>
                  <Box
                    sx={{
                      width: 58,
                      height: 58,
                      borderRadius: 3,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      bgcolor: "#eaf2ff",
                      mb: 3,
                    }}
                  >
                    <SupportAgentRounded
                      sx={{
                        color: "#2563eb",
                        fontSize: 30,
                      }}
                    />
                  </Box>

                  <Typography variant="h6" fontWeight={800}>
                    Customer Support
                  </Typography>

                  <Typography
                    sx={{
                      mt: 1,
                      color: "#64748b",
                      lineHeight: 1.7,
                    }}
                  >
                    Get help whenever you need it
                    throughout your stay.
                  </Typography>
                </CardContent>
              </Card>
            </Grid>

          </Grid>

          <Box
            sx={{
              mt: 6,
              textAlign: "center",
            }}
          >
            <Button
              variant="contained"
              onClick={() => navigate("/pgs")}
              endIcon={<ArrowForwardRounded />}
              sx={{
                px: 3.5,
                py: 1.4,
                borderRadius: 3,
                bgcolor: "#2563eb",
                fontWeight: 800,
                textTransform: "none",
              }}
            >
              Explore PGs
            </Button>
          </Box>

        </Container>
      </Box>


      {/* CONTACT */}

      <Box
        id="contact"
        sx={{
          py: { xs: 8, md: 11 },
          bgcolor: "#f4f7fb",
          scrollMarginTop: "80px",
        }}
      >
        <Container maxWidth="lg">

          <Box
            sx={{
              position: "relative",
              overflow: "hidden",
              bgcolor: "#101d41",
              color: "#fff",
              borderRadius: 6,
              p: { xs: 4, md: 7 },
              textAlign: "center",
              boxShadow: "0 25px 60px rgba(15,23,42,0.15)",
            }}
          >

            <Box
              sx={{
                position: "absolute",
                width: 220,
                height: 220,
                borderRadius: "50%",
                bgcolor: "rgba(37,99,235,0.18)",
                top: -120,
                left: -70,
              }}
            />

            <Box
              sx={{
                position: "relative",
                zIndex: 2,
              }}
            >

              <Typography
                sx={{
                  color: "#60a5fa",
                  fontWeight: 800,
                  letterSpacing: 2,
                }}
              >
                GET IN TOUCH
              </Typography>

              <Typography
                component="h2"
                sx={{
                  mt: 1.5,
                  fontWeight: 900,
                  fontSize: { xs: 36, md: 54 },
                }}
              >
                Need help finding a PG?
              </Typography>

              <Typography
                sx={{
                  mt: 2,
                  color: "#cbd5e1",
                  fontSize: 18,
                }}
              >
                Our team is here to help you find a
                comfortable and suitable place to stay.
              </Typography>

              <Stack
                direction={{ xs: "column", sm: "row" }}
                justifyContent="center"
                spacing={2}
                sx={{ mt: 4 }}
              >

                <Button
                  variant="contained"
                  onClick={() => navigate("/pgs")}
                  sx={{
                    px: 4,
                    py: 1.5,
                    borderRadius: 3,
                    bgcolor: "#2563eb",
                    fontWeight: 800,
                    textTransform: "none",
                  }}
                >
                  Find a PG
                </Button>

                <Button
                  variant="outlined"
                  href="mailto:support@smartstay.com"
                  startIcon={<SupportAgentRounded />}
                  sx={{
                    px: 3.5,
                    py: 1.5,
                    borderRadius: 3,
                    fontWeight: 800,
                    textTransform: "none",
                    color: "#fff",
                    borderColor: "#64748b",
                  }}
                >
                  Email Support
                </Button>

              </Stack>

            </Box>
          </Box>

        </Container>
      </Box>

    </Box>
  );
}