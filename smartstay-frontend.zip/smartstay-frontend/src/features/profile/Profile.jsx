import { useEffect, useState } from "react";
import { Alert, Button, Container, Grid, Paper, TextField, Typography } from "@mui/material";
import axios from "../../api/axiosInstance";
import { API } from "../../api/apiEndpoints";
import { useAuth } from "../../context/AuthContext";

export default function Profile(){
  const {user}=useAuth();
  const [profile,setProfile]=useState(null),[form,setForm]=useState({}),[message,setMessage]=useState(""),[error,setError]=useState(""),[loading,setLoading]=useState(true),[saving,setSaving]=useState(false);
  useEffect(()=>{
    if(!user?.id){setLoading(false);return;}
    axios.get(API.USERS.BY_AUTH_ID(user.id)).then(r=>{setProfile(r.data);setForm(r.data);})
      .catch(e=>{if(e.response?.status!==404)setError(e?.response?.data?.message||"Unable to load profile.");})
      .finally(()=>setLoading(false));
  },[user?.id]);
  const save=async()=>{
    setSaving(true);setMessage("");setError("");
    try{
      const payload={...form,authUserId:Number(user.id),email:form.email||user.email,fullName:form.fullName||user.fullName};
      if(profile) { const r=await axios.put(API.USERS.BY_ID(profile.id),payload);setProfile(r.data);setForm(r.data); }
      else { const r=await axios.post(API.USERS.BASE,{...payload,phone:form.phone||user.phone||""});setProfile(r.data);setForm(r.data); }
      setMessage("Profile saved successfully.");
    }catch(e){setError(e?.response?.data?.message||"Unable to save profile.");}
    finally{setSaving(false);}
  };
  if(loading)return <Container sx={{py:5}}><Typography>Loading profile...</Typography></Container>;
  return <Container maxWidth="md" sx={{py:5}}><Typography variant="h3">My Profile</Typography>
    <Paper sx={{p:{xs:2,md:4},mt:3}}><Grid container spacing={2}>
      {["fullName","phone","gender","dateOfBirth","city","address","occupation"].map(k=><Grid item xs={12} md={6} key={k}><TextField fullWidth label={k.replace(/([A-Z])/g," $1")} value={form[k]||""} onChange={e=>setForm({...form,[k]:e.target.value})}/></Grid>)}
      <Grid item xs={12}><TextField fullWidth label="Email" value={form.email||user?.email||""} InputProps={{readOnly:true}}/></Grid>
      <Grid item xs={12}><TextField fullWidth multiline minRows={3} label="Bio" value={form.bio||""} onChange={e=>setForm({...form,bio:e.target.value})}/></Grid>
      {error&&<Grid item xs={12}><Alert severity="error">{error}</Alert></Grid>}
      {message&&<Grid item xs={12}><Alert severity="success">{message}</Alert></Grid>}
      <Grid item xs={12}><Button variant="contained" onClick={save} disabled={saving}>{saving?"Saving...":"Save Changes"}</Button></Grid>
    </Grid></Paper></Container>;
}
