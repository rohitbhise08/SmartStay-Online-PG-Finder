import { useEffect, useState } from "react";
import {
  Box,
  Button,
  Chip,
  Container,
  Divider,
  Paper,
  Stack,
  Typography
} from "@mui/material";

import {
  ArrowBackRounded,
  EventAvailableRounded,
  KingBedRounded,
  PaymentRounded,
  HomeRounded,
  CheckCircleRounded
} from "@mui/icons-material";

import { useNavigate, useParams } from "react-router-dom";

import axios from "../../api/axiosInstance";
import { API } from "../../api/apiEndpoints";

import Loader from "../../components/common/Loader";

export default function BookingDetails() {

  const { id } = useParams();
  const navigate = useNavigate();

  const [b, setB] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {

    axios
      .get(API.BOOKINGS.BY_ID(id))
      .then((r) => setB(r.data?.data || r.data))
      .catch(setError);

  }, [id]);

  if (!b && !error) {
    return <Loader fullPage />;
  }

  if (error) {
    return (
      <Container sx={{ py: 5 }}>
        <Typography color="error">
          Unable to load booking.
        </Typography>
      </Container>
    );
  }

  const status =
    b.bookingStatus ||
    b.status ||
    "PENDING";

  const payment =
    b.paymentStatus ||
    "-";

  const statusColor =
    status === "CONFIRMED"
      ? "success"
      : status === "CANCELLED"
      ? "error"
      : "warning";

  return (
    <Box
      sx={{
        bgcolor: "#f8fafc",
        minHeight: "calc(100vh - 74px)",
        py: { xs: 4, md: 6 }
      }}
    >

      <Container maxWidth="md">

        {/* BACK */}

        <Button
          startIcon={<ArrowBackRounded />}
          onClick={() => navigate("/bookings")}
          sx={{
            mb: 3,
            fontWeight: 700,
            textTransform: "none"
          }}
        >
          Back to My Bookings
        </Button>

        {/* HEADER */}

        <Box sx={{ mb: 4 }}>

          <Typography
            sx={{
              color: "primary.main",
              fontWeight: 800,
              fontSize: 14,
              letterSpacing: 1
            }}
          >
            SMARTSTAY
          </Typography>

          <Typography
            sx={{
              fontSize: {
                xs: 32,
                md: 44
              },
              fontWeight: 900,
              mt: 1
            }}
          >
            Booking Details
          </Typography>

          <Typography
            color="text.secondary"
            sx={{ mt: 1 }}
          >
            Booking ID #{b.id}
          </Typography>

        </Box>

        {/* BOOKING CARD */}

        <Paper
          elevation={0}
          sx={{
            borderRadius: 4,
            border: "1px solid #e5e7eb",
            overflow: "hidden",
            bgcolor: "white"
          }}
        >

          {/* STATUS HEADER */}

          <Box
            sx={{
              p: 3,
              bgcolor: "#f8fafc",
              borderBottom: "1px solid #e5e7eb",
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              gap: 2
            }}
          >

            <Stack
              direction="row"
              alignItems="center"
              spacing={1}
            >

              <CheckCircleRounded
                color={
                  status === "CONFIRMED"
                    ? "success"
                    : "warning"
                }
              />

              <Typography fontWeight={800}>
                Booking Status
              </Typography>

            </Stack>

            <Chip
              label={String(status).replaceAll("_", " ")}
              color={statusColor}
              size="small"
            />

          </Box>

          {/* DETAILS */}

          <Box sx={{ p: { xs: 2.5, md: 4 } }}>

            <Typography
              fontSize={20}
              fontWeight={900}
            >
              Stay Information
            </Typography>

            <Box
              sx={{
                display: "grid",
                gridTemplateColumns: {
                  xs: "1fr",
                  sm: "1fr 1fr"
                },
                gap: 3,
                mt: 3
              }}
            >

              {/* PG */}

              <Box
                sx={{
                  display: "flex",
                  gap: 1.5,
                  alignItems: "center"
                }}
              >

                <HomeRounded color="primary" />

                <Box>
                  <Typography
                    fontSize={12}
                    color="text.secondary"
                  >
                    PG ID
                  </Typography>

                  <Typography fontWeight={800}>
                    {b.pgId}
                  </Typography>
                </Box>

              </Box>

              {/* BEDS */}

              <Box
                sx={{
                  display: "flex",
                  gap: 1.5,
                  alignItems: "center"
                }}
              >

                <KingBedRounded color="primary" />

                <Box>
                  <Typography
                    fontSize={12}
                    color="text.secondary"
                  >
                    Number of Beds
                  </Typography>

                  <Typography fontWeight={800}>
                    {b.numberOfBeds || 0}
                  </Typography>
                </Box>

              </Box>

              {/* CHECK-IN */}

              <Box
                sx={{
                  display: "flex",
                  gap: 1.5,
                  alignItems: "center"
                }}
              >

                <EventAvailableRounded color="primary" />

                <Box>
                  <Typography
                    fontSize={12}
                    color="text.secondary"
                  >
                    Check-in
                  </Typography>

                  <Typography fontWeight={800}>
                    {b.checkInDate || "-"}
                  </Typography>
                </Box>

              </Box>

              {/* CHECK-OUT */}

              <Box
                sx={{
                  display: "flex",
                  gap: 1.5,
                  alignItems: "center"
                }}
              >

                <EventAvailableRounded color="primary" />

                <Box>
                  <Typography
                    fontSize={12}
                    color="text.secondary"
                  >
                    Check-out
                  </Typography>

                  <Typography fontWeight={800}>
                    {b.checkOutDate || "-"}
                  </Typography>
                </Box>

              </Box>

            </Box>

            <Divider sx={{ my: 4 }} />

            {/* PAYMENT */}

            <Typography
              fontSize={20}
              fontWeight={900}
            >
              Payment Information
            </Typography>

            <Stack
              spacing={2}
              sx={{ mt: 3 }}
            >

              <Box
                sx={{
                  display: "flex",
                  justifyContent: "space-between"
                }}
              >
                <Typography color="text.secondary">
                  Monthly Rent
                </Typography>

                <Typography fontWeight={800}>
                  ₹{Number(
                    b.monthlyRent || 0
                  ).toLocaleString()}
                </Typography>
              </Box>

              <Box
                sx={{
                  display: "flex",
                  justifyContent: "space-between"
                }}
              >
                <Typography color="text.secondary">
                  Security Deposit
                </Typography>

                <Typography fontWeight={800}>
                  ₹{Number(
                    b.securityDeposit || 0
                  ).toLocaleString()}
                </Typography>
              </Box>

              <Divider />

              <Box
                sx={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center"
                }}
              >

                <Typography
                  fontSize={18}
                  fontWeight={900}
                >
                  Total Amount
                </Typography>

                <Typography
                  fontSize={24}
                  fontWeight={900}
                  color="primary.main"
                >
                  ₹{Number(
                    b.totalAmount || 0
                  ).toLocaleString()}
                </Typography>

              </Box>

            </Stack>

            {/* PAYMENT STATUS */}

            <Box
              sx={{
                mt: 3,
                p: 2,
                borderRadius: 2,
                bgcolor: "#f8fafc",
                display: "flex",
                alignItems: "center",
                gap: 1
              }}
            >

              <PaymentRounded color="primary" />

              <Box>
                <Typography
                  fontSize={12}
                  color="text.secondary"
                >
                  Payment Status
                </Typography>

                <Typography fontWeight={800}>
                  {String(payment).replaceAll(
                    "_",
                    " "
                  )}
                </Typography>
              </Box>

            </Box>

            {/* BUTTON */}

            <Button
              fullWidth
              variant="contained"
              onClick={() => navigate("/bookings")}
              sx={{
                mt: 4,
                py: 1.4,
                borderRadius: 2.5,
                fontWeight: 800,
                textTransform: "none",
                fontSize: 15
              }}
            >
              Back to My Bookings
            </Button>

          </Box>

        </Paper>

      </Container>

    </Box>
  );
}