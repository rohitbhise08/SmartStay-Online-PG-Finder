import { useEffect, useState } from "react";
import {
  Alert,
  Box,
  Container,
  Paper,
  Stack,
  Typography
} from "@mui/material";

import {
  EventAvailableRounded,
  LocationOnRounded,
  SecurityRounded
} from "@mui/icons-material";

import { useSearchParams, useNavigate } from "react-router-dom";

import axios from "../../api/axiosInstance";
import { API } from "../../api/apiEndpoints";

import BookingForm from "../../components/booking/BookingForm";
import Loader from "../../components/common/Loader";

import { useAuth } from "../../context/AuthContext";

export default function Booking() {

  const [params] = useSearchParams();

  const pgId = params.get("pgId");

  const [pg, setPg] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const navigate = useNavigate();
  const { user } = useAuth();

  useEffect(() => {

    if (!pgId) {
      setError("PG ID is missing.");
      setLoading(false);
      return;
    }

    axios
      .get(API.PGS.BY_ID(pgId))
      .then((r) => setPg(r.data))
      .catch((e) =>
        setError(
          e?.response?.data?.message ||
          "Unable to load PG."
        )
      )
      .finally(() => setLoading(false));

  }, [pgId]);

  const submit = async (form) => {

    if (!user?.id) {
      setError("User ID is missing. Please login again.");
      return;
    }

    setSaving(true);
    setError("");

    try {

      const payload = {
        userId: Number(user.id),
        pgId: Number(pgId),
        checkInDate: form.checkInDate,
        checkOutDate: form.checkOutDate || null,
        numberOfBeds: Number(form.numberOfBeds),
        specialRequest: form.specialRequest || ""
      };

      const r = await axios.post(
        API.BOOKINGS.BASE,
        payload
      );

      navigate(`/bookings/${r.data.id}`);

    } catch (e) {

      setError(
        e?.response?.data?.message ||
        "Unable to create booking."
      );

    } finally {

      setSaving(false);

    }
  };

  if (loading) {
    return <Loader fullPage />;
  }

  return (
    <Box
      sx={{
        bgcolor: "#f8fafc",
        minHeight: "calc(100vh - 74px)",
        py: { xs: 4, md: 6 }
      }}
    >

      <Container maxWidth="lg">

        {/* =====================================================
            PAGE HEADER
        ===================================================== */}

        <Box sx={{ mb: 4 }}>

          <Typography
            sx={{
              color: "primary.main",
              fontWeight: 800,
              fontSize: 14,
              letterSpacing: 1
            }}
          >
            SMARTSTAY BOOKING
          </Typography>

          <Typography
            sx={{
              fontSize: {
                xs: 34,
                md: 46
              },
              fontWeight: 900,
              mt: 1
            }}
          >
            Complete your booking
          </Typography>

          <Typography
            color="text.secondary"
            sx={{
              mt: 1,
              fontSize: 16
            }}
          >
            Choose your dates and preferences to
            send your booking request.
          </Typography>

        </Box>

        {/* ERROR */}

        {error && (
          <Alert
            severity="error"
            sx={{
              mb: 3,
              borderRadius: 2
            }}
          >
            {String(error)}
          </Alert>
        )}

        {pg ? (

          <Box
            sx={{
              display: "grid",
              gridTemplateColumns: {
                xs: "1fr",
                md: "0.75fr 1.25fr"
              },
              gap: 3,
              alignItems: "start"
            }}
          >

            {/* =================================================
                PG SUMMARY
            ================================================= */}

            <Paper
              elevation={0}
              sx={{
                p: 3,
                borderRadius: 4,
                border: "1px solid #e5e7eb",
                bgcolor: "white"
              }}
            >

              <Typography
                fontSize={20}
                fontWeight={900}
              >
                Your selected PG
              </Typography>

              <Box
                component="img"
                src={
                  pg.imageUrl ||
                  pg.image ||
                  pg.photoUrl ||
                  "https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=900&q=85"
                }
                alt={pg.name || "PG"}
                sx={{
                  width: "100%",
                  height: 220,
                  objectFit: "cover",
                  borderRadius: 3,
                  mt: 2
                }}
              />

              <Typography
                fontSize={23}
                fontWeight={900}
                sx={{ mt: 2 }}
              >
                {pg.name || "PG Accommodation"}
              </Typography>

              <Typography
                color="text.secondary"
                sx={{
                  display: "flex",
                  alignItems: "center",
                  gap: 0.5,
                  mt: 1
                }}
              >
                <LocationOnRounded
                  fontSize="small"
                  color="primary"
                />

                {pg.area
                  ? `${pg.area}, `
                  : ""}
                {pg.city || "Location"}
              </Typography>

              <Typography
                sx={{
                  fontSize: 25,
                  fontWeight: 900,
                  color: "primary.main",
                  mt: 2
                }}
              >
                ₹
                {Number(
                  pg.monthlyRent ??
                  pg.rent ??
                  0
                ).toLocaleString()}

                <Typography
                  component="span"
                  color="text.secondary"
                  fontSize={14}
                  fontWeight={500}
                >
                  {" "}
                  / month
                </Typography>
              </Typography>

              <Stack
                spacing={1.5}
                sx={{ mt: 3 }}
              >

                <Box
                  sx={{
                    display: "flex",
                    alignItems: "center",
                    gap: 1
                  }}
                >
                  <EventAvailableRounded
                    color="primary"
                  />

                  <Typography
                    fontSize={14}
                    color="text.secondary"
                  >
                    Easy booking request
                  </Typography>
                </Box>

                <Box
                  sx={{
                    display: "flex",
                    alignItems: "center",
                    gap: 1
                  }}
                >
                  <SecurityRounded
                    color="primary"
                  />

                  <Typography
                    fontSize={14}
                    color="text.secondary"
                  >
                    Secure booking process
                  </Typography>
                </Box>

              </Stack>

            </Paper>

            {/* =================================================
                BOOKING FORM
            ================================================= */}

            <BookingForm
              pg={pg}
              onSubmit={submit}
              loading={saving}
            />

          </Box>

        ) : (

          <Alert
            severity="warning"
            sx={{ borderRadius: 2 }}
          >
            PG was not found.
          </Alert>

        )}

      </Container>

    </Box>
  );
}