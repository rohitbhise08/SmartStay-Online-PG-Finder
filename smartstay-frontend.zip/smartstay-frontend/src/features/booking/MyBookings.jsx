import { useEffect, useState } from "react";
import {
  Box,
  Chip,
  Container,
  Paper,
  Stack,
  Typography
} from "@mui/material";

import {
  EventAvailableRounded,
  HomeRounded,
  LocationOnRounded
} from "@mui/icons-material";

import axios from "../../api/axiosInstance";
import { API } from "../../api/apiEndpoints";

import Loader from "../../components/common/Loader";
import ErrorMessage from "../../components/common/ErrorMessage";
import BookingCard from "../../components/booking/BookingCard";

import { useAuth } from "../../context/AuthContext";

export default function MyBookings() {

  const { user } = useAuth();

  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {

    if (!user?.id) {
      setError("User ID not available.");
      setLoading(false);
      return;
    }

    axios
      .get(API.BOOKINGS.BY_USER(user.id))
      .then((r) => {
        setData(
          Array.isArray(r.data)
            ? r.data
            : []
        );
      })
      .catch((e) =>
        setError(
          e?.response?.data?.message ||
          "Unable to load bookings."
        )
      )
      .finally(() => setLoading(false));

  }, [user?.id]);

  return (
    <Box
      sx={{
        bgcolor: "#f8fafc",
        minHeight: "calc(100vh - 74px)",
        py: { xs: 4, md: 6 }
      }}
    >

      <Container maxWidth="xl">

        {/* PAGE HEADER */}

        <Box sx={{ mb: 4 }}>

          <Stack
            direction="row"
            alignItems="center"
            spacing={1}
            sx={{ mb: 1 }}
          >

            <EventAvailableRounded
              color="primary"
            />

            <Typography
              sx={{
                color: "primary.main",
                fontWeight: 800,
                fontSize: 14,
                letterSpacing: 1,
                textTransform: "uppercase"
              }}
            >
              SmartStay
            </Typography>

          </Stack>

          <Typography
            sx={{
              fontSize: {
                xs: 34,
                md: 46
              },
              fontWeight: 900,
              lineHeight: 1.1
            }}
          >
            My Bookings
          </Typography>

          <Typography
            color="text.secondary"
            sx={{
              mt: 1,
              fontSize: 16
            }}
          >
            View and manage all your PG booking requests.
          </Typography>

        </Box>

        {/* LOADING */}

        {loading && <Loader />}

        {/* ERROR */}

        {!loading && (
          <ErrorMessage error={error} />
        )}

        {/* BOOKINGS */}

        {!loading && !error && data.length > 0 && (

          <Box
            sx={{
              display: "grid",
              gridTemplateColumns: {
                xs: "1fr",
                md: "repeat(2, 1fr)"
              },
              gap: 3
            }}
          >

            {data.map((booking) => (

              <BookingCard
                key={booking.id}
                booking={booking}
              />

            ))}

          </Box>

        )}

        {/* EMPTY STATE */}

        {!loading && !error && data.length === 0 && (

          <Paper
            elevation={0}
            sx={{
              py: 9,
              px: 3,
              textAlign: "center",
              borderRadius: 4,
              border: "1px solid #e5e7eb",
              bgcolor: "white"
            }}
          >

            <HomeRounded
              sx={{
                fontSize: 55,
                color: "#cbd5e1"
              }}
            />

            <Typography
              variant="h5"
              fontWeight={900}
              sx={{ mt: 2 }}
            >
              No bookings yet
            </Typography>

            <Typography
              color="text.secondary"
              sx={{
                mt: 1,
                maxWidth: 450,
                mx: "auto"
              }}
            >
              You haven't made any PG bookings yet.
              Explore available PGs and find your
              perfect stay.
            </Typography>

          </Paper>

        )}

      </Container>

    </Box>
  );
}