import { useEffect, useState } from "react";
import { Alert, Button, Container, Grid, Paper, TextField, Typography } from "@mui/material";
import { useNavigate, useParams } from "react-router-dom";
import axios from "../../api/axiosInstance";
import { API } from "../../api/apiEndpoints";
import Loader from "../../components/common/Loader";

export default function EditPG(){
 const {id}=useParams(),navigate=useNavigate(); const [form,setForm]=useState(null),[error,setError]=useState(""),[loading,setLoading]=useState(false);
 useEffect(()=>{axios.get(API.PGS.BY_ID(id)).then(r=>setForm(r.data?.data||r.data)).catch(setError)},[id]);
 if(!form&&!error)return <Loader fullPage/>; if(error)return <Container sx={{py:5}}><Alert severity="error">Unable to load PG.</Alert></Container>;
 const update=e=>setForm({...form,[e.target.name]:e.target.value});
 const submit=async e=>{e.preventDefault();setLoading(true);try{await axios.put(API.PGS.BY_ID(id),{...form,monthlyRent:Number(form.monthlyRent||form.rent)});navigate(`/pgs/${id}`)}catch(err){setError(err)}finally{setLoading(false)}};
 return <Container maxWidth="md" sx={{py:5}}><Typography variant="h3">Edit PG</Typography><Paper sx={{p:4,mt:3}}><form onSubmit={submit}><Grid container spacing={2}>{["name","description","address","city","area","monthlyRent","securityDeposit","availableBeds","totalBeds"].map(k=><Grid item xs={12} md={["description","address"].includes(k)?12:6} key={k}><TextField fullWidth name={k} label={k} value={form[k]??""} onChange={update}/></Grid>)}<Grid item xs={12}>{error&&<Alert severity="error">Update failed.</Alert>}</Grid><Grid item xs={12}><Button type="submit" variant="contained" disabled={loading}>{loading?"Updating...":"Update PG"}</Button></Grid></Grid></form></Paper></Container>;
}
