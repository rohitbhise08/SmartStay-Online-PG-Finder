import { useEffect, useMemo, useState } from "react";

import {
  Box,
  Chip,
  Container,
  Paper,
  Stack,
  Typography,
} from "@mui/material";

import {
  HomeRounded,
  LocationOnRounded,
} from "@mui/icons-material";

import { useSearchParams } from "react-router-dom";

import axios from "../../api/axiosInstance";
import { API } from "../../api/apiEndpoints";

import Loader from "../../components/common/Loader";
import ErrorMessage from "../../components/common/ErrorMessage";

import PGGrid from "../../components/pg/PGGrid";
import PGSearch from "../../components/pg/PGSearch";
import PGFilter from "../../components/pg/PGFilter";


export default function PGList() {

  const [params] = useSearchParams();

  const [pgs, setPgs] = useState([]);

  const [search, setSearch] = useState(
    params.get("search") || ""
  );

  const [gender, setGender] = useState("");

  const [city, setCity] = useState(
    params.get("city") || ""
  );

  const [loading, setLoading] = useState(true);

  const [error, setError] = useState("");


  /* ================================
     LOAD PGs
  ================================= */

  useEffect(() => {

    const loadPGs = async () => {

      try {

        setLoading(true);
        setError("");

        const response = await axios.get(
          API.PGS.BASE
        );

        const data = response.data;

        setPgs(
          Array.isArray(data)
            ? data
            : data?.content ||
              data?.data ||
              []
        );

      } catch (e) {

        setError(e);

      } finally {

        setLoading(false);

      }

    };

    loadPGs();

  }, []);


  /* ================================
     FILTER PGs
  ================================= */

  const filtered = useMemo(() => {

    return pgs.filter((pg) => {

      const q = search
        .trim()
        .toLowerCase();

      const haystack =
        `${pg.name || ""} ${pg.city || ""} ${pg.area || ""}`
          .toLowerCase();

      const matchesSearch =
        !q || haystack.includes(q);

      const matchesCity =
        !city ||
        String(pg.city || "")
          .toLowerCase()
          .includes(city.toLowerCase());

      const matchesGender =
        !gender ||
        String(
          pg.genderPreference ||
          pg.gender ||
          ""
        ).toUpperCase() ===
          String(gender).toUpperCase();

      return (
        matchesSearch &&
        matchesCity &&
        matchesGender
      );

    });

  }, [pgs, search, city, gender]);


  /* ================================
     CLEAR FILTERS
  ================================= */

  const clearFilters = () => {

    setSearch("");
    setCity("");
    setGender("");

  };


  return (

    <Box
      sx={{
        minHeight: "calc(100vh - 74px)",
        backgroundColor: "#f8fafc",
        py: {
          xs: 4,
          md: 6,
        },
      }}
    >

      <Container maxWidth="xl">


        {/* ================================
            PAGE HEADER
        ================================= */}

        <Box sx={{ mb: 4 }}>

          <Stack
            direction="row"
            alignItems="center"
            spacing={1}
            sx={{ mb: 1 }}
          >

            <HomeRounded
              sx={{
                color: "#2563eb",
              }}
            />

            <Typography
              sx={{
                color: "#2563eb",
                fontWeight: 800,
                fontSize: 14,
                letterSpacing: 1,
                textTransform: "uppercase",
              }}
            >
              SmartStay Properties
            </Typography>

          </Stack>


          <Typography
            sx={{
              fontSize: {
                xs: 36,
                sm: 42,
                md: 52,
              },
              fontWeight: 900,
              lineHeight: 1.1,
              color: "#111827",
            }}
          >
            Find your perfect PG
          </Typography>


          <Typography
            sx={{
              mt: 1.5,
              fontSize: 17,
              maxWidth: 720,
              color: "#64748b",
            }}
          >
            Explore comfortable PG accommodations,
            compare amenities and find a place that
            fits your lifestyle.
          </Typography>

        </Box>


        {/* ================================
            SEARCH + FILTER
        ================================= */}

        <Paper
          elevation={0}
          sx={{
            p: {
              xs: 2,
              md: 2.5,
            },
            mb: 5,
            borderRadius: 4,
            border: "1px solid #e5e7eb",
            backgroundColor: "#ffffff",
            boxShadow:
              "0 8px 30px rgba(15,23,42,0.05)",
          }}
        >

          <Box
            sx={{
              display: "grid",
              gridTemplateColumns: {
                xs: "1fr",
                md: "1.2fr 1fr",
              },
              gap: 2,
            }}
          >


            {/* SEARCH */}

            <Box>

              <Typography
                fontSize={13}
                fontWeight={800}
                sx={{
                  mb: 1,
                  color: "#111827",
                }}
              >
                SEARCH LOCATION OR PG
              </Typography>

              <PGSearch
                value={search}
                onChange={setSearch}
              />

            </Box>


            {/* FILTER */}

            <Box>

              <Typography
                fontSize={13}
                fontWeight={800}
                sx={{
                  mb: 1,
                  color: "#111827",
                }}
              >
                FILTER PROPERTIES
              </Typography>

              <PGFilter
                gender={gender}
                setGender={setGender}
                city={city}
                setCity={setCity}
              />

            </Box>

          </Box>

        </Paper>


        {/* ================================
            RESULTS HEADER
        ================================= */}

        {!loading && !error && (

          <Box
            sx={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: {
                xs: "flex-start",
                md: "center",
              },
              flexDirection: {
                xs: "column",
                md: "row",
              },
              gap: 2,
              mb: 3,
            }}
          >

            <Box>

              <Typography
                sx={{
                  fontSize: 25,
                  fontWeight: 900,
                  color: "#111827",
                }}
              >
                Available PGs
              </Typography>

              <Typography
                sx={{
                  color: "#64748b",
                  fontSize: 14,
                  mt: 0.5,
                }}
              >
                {filtered.length}{" "}
                {filtered.length === 1
                  ? "property"
                  : "properties"}{" "}
                found
              </Typography>

            </Box>


            {/* ACTIVE FILTERS */}

            <Stack
              direction="row"
              spacing={1}
              flexWrap="wrap"
              useFlexGap
            >

              {search && (

                <Chip
                  label={`Search: ${search}`}
                  onDelete={() => setSearch("")}
                  size="small"
                />

              )}


              {city && (

                <Chip
                  icon={<LocationOnRounded />}
                  label={city}
                  onDelete={() => setCity("")}
                  size="small"
                />

              )}


              {gender && (

                <Chip
                  label={gender}
                  onDelete={() => setGender("")}
                  size="small"
                />

              )}


              {(search || city || gender) && (

                <Chip
                  label="Clear filters"
                  variant="outlined"
                  onClick={clearFilters}
                  size="small"
                />

              )}

            </Stack>

          </Box>

        )}


        {/* ================================
            LOADING
        ================================= */}

        {loading && <Loader />}


        {/* ================================
            ERROR
        ================================= */}

        {!loading && (
          <ErrorMessage error={error} />
        )}


        {/* ================================
            PG GRID
        ================================= */}

        {!loading &&
          !error &&
          filtered.length > 0 && (

            <PGGrid
              pgs={filtered}
            />

          )}


        {/* ================================
            EMPTY STATE
        ================================= */}

        {!loading &&
          !error &&
          filtered.length === 0 && (

            <Paper
              elevation={0}
              sx={{
                py: 10,
                px: 3,
                textAlign: "center",
                borderRadius: 4,
                border: "1px solid #e5e7eb",
                backgroundColor: "#ffffff",
              }}
            >

              <HomeRounded
                sx={{
                  fontSize: 55,
                  color: "#cbd5e1",
                }}
              />

              <Typography
                variant="h5"
                fontWeight={900}
                sx={{
                  mt: 2,
                }}
              >
                No PGs found
              </Typography>

              <Typography
                color="text.secondary"
                sx={{
                  mt: 1,
                  maxWidth: 450,
                  mx: "auto",
                }}
              >
                We couldn't find any PG matching
                your search or filters. Try another
                location or clear the filters.
              </Typography>

            </Paper>

          )}

      </Container>

    </Box>

  );

}