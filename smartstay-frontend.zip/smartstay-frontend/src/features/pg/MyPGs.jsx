import { useEffect, useState } from "react";
import { Button, Chip, Container, Paper, Stack, Table, TableBody, TableCell, TableHead, TableRow, Typography } from "@mui/material";
import { Link } from "react-router-dom";
import axios from "../../api/axiosInstance";
import { API } from "../../api/apiEndpoints";
import Loader from "../../components/common/Loader";
import ErrorMessage from "../../components/common/ErrorMessage";
import { useAuth } from "../../context/AuthContext";

export default function MyPGs() {
  const { user } = useAuth();
  const [pgs,setPgs]=useState([]),[loading,setLoading]=useState(true),[error,setError]=useState("");
  const load=async()=>{
    if(!user?.id){setError("User ID not available.");setLoading(false);return;}
    try{const r=await axios.get(API.PGS.BY_OWNER(user.id));setPgs(Array.isArray(r.data)?r.data:[]);}
    catch(e){setError(e?.response?.data?.message||"Unable to load your PGs.");}
    finally{setLoading(false);}
  };
  useEffect(()=>{load();},[user?.id]);
  return <Container maxWidth="xl" sx={{py:5}}>
    <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{mb:3}}>
      <Typography variant="h3">My PGs</Typography>
      <Button component={Link} to="/pgs/add" variant="contained">+ Add PG</Button>
    </Stack>
    {loading?<Loader/>:<><ErrorMessage error={error}/><Paper sx={{overflowX:"auto"}}><Table>
      <TableHead><TableRow><TableCell>Name</TableCell><TableCell>Location</TableCell><TableCell>Rent</TableCell><TableCell>Status</TableCell><TableCell>Action</TableCell></TableRow></TableHead>
      <TableBody>{pgs.map(pg=><TableRow key={pg.id}><TableCell>{pg.name}</TableCell><TableCell>{pg.city}</TableCell><TableCell>₹{pg.monthlyRent?.toLocaleString()}</TableCell><TableCell><Chip size="small" label={pg.status}/></TableCell><TableCell><Button component={Link} to={`/pgs/edit/${pg.id}`}>Edit</Button></TableCell></TableRow>)}</TableBody>
    </Table></Paper></>}
  </Container>;
}
