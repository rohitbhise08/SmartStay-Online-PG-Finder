import { useState } from "react";
import {
  Alert, Button, Container, FormControlLabel, Grid, Paper, Switch,
  TextField, Typography
} from "@mui/material";
import { useNavigate } from "react-router-dom";
import axios from "../../api/axiosInstance";
import { API } from "../../api/apiEndpoints";
import { PG_STATUS } from "../../utils/constants";
import { useAuth } from "../../context/AuthContext";

const initial = {
  name: "", description: "", propertyType: "PG", address: "", city: "", area: "",
  latitude: "", longitude: "", monthlyRent: "", securityDeposit: "",
  totalBeds: 1, availableBeds: 1, genderPreference: "ANY",
  foodAvailable: false, foodType: "", furnished: false, acAvailable: false,
  wifiAvailable: false, parkingAvailable: false, laundryAvailable: false,
  powerBackup: false, securityAvailable: false,
};

const numeric = ["latitude","longitude","monthlyRent","securityDeposit","totalBeds","availableBeds"];

export default function AddPG() {
  const [form, setForm] = useState(initial);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const { user } = useAuth();

  const update = (e) => {
    const { name, value, type, checked } = e.target;
    setForm(f => ({ ...f, [name]: type === "checkbox" ? checked : value }));
  };

  const submit = async (e) => {
    e.preventDefault();
    setError("");
    if (!user?.id) return setError("Your authenticated user ID is missing. Please login again.");
    setLoading(true);
    try {
      const payload = {
        ...form,
        ownerId: Number(user.id),
        status: PG_STATUS.PENDING_APPROVAL,
        ...Object.fromEntries(numeric.map(k => [k, form[k] === "" ? null : Number(form[k])])),
      };
      const r = await axios.post(API.PGS.BASE, payload);
      navigate(`/pgs/${r.data?.id}`);
    } catch (err) {
      setError(err?.response?.data?.message || err?.response?.data || "Unable to add PG.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Container maxWidth="lg" sx={{ py: 5 }}>
      <Typography variant="h3" fontWeight={900}>Add New PG</Typography>
      <Typography color="text.secondary" sx={{ mb: 3 }}>Submit your property for admin approval.</Typography>
      <Paper sx={{ p: { xs: 2, md: 4 } }}>
        {error && <Alert severity="error" sx={{ mb: 3 }}>{String(error)}</Alert>}
        <form onSubmit={submit}>
          <Grid container spacing={2}>
            {[
              ["name","PG Name",true],["propertyType","Property Type",true],
              ["address","Address",true],["city","City",true],["area","Area",false],
              ["description","Description",false],["monthlyRent","Monthly Rent",true],
              ["securityDeposit","Security Deposit",false],["totalBeds","Total Beds",true],
              ["availableBeds","Available Beds",true],["genderPreference","Gender Preference",true],
              ["foodType","Food Type",false],["latitude","Latitude",false],["longitude","Longitude",false],
            ].map(([name,label,required]) => (
              <Grid item xs={12} md={name==="description"||name==="address"?12:6} key={name}>
                <TextField
                  fullWidth multiline={name==="description"} minRows={name==="description"?4:1}
                  name={name} label={label} value={form[name]}
                  onChange={update} required={required}
                  type={numeric.includes(name) ? "number" : "text"}
                />
              </Grid>
            ))}
            {[
              ["foodAvailable","Food Available"],["furnished","Furnished"],["acAvailable","AC Available"],
              ["wifiAvailable","Wi-Fi"],["parkingAvailable","Parking"],["laundryAvailable","Laundry"],
              ["powerBackup","Power Backup"],["securityAvailable","Security Available"],
            ].map(([name,label]) => (
              <Grid item xs={12} sm={6} md={3} key={name}>
                <FormControlLabel control={<Switch name={name} checked={form[name]} onChange={update}/>} label={label}/>
              </Grid>
            ))}
            <Grid item xs={12}>
              <Button type="submit" variant="contained" size="large" disabled={loading}>
                {loading ? "Submitting..." : "Submit PG"}
              </Button>
            </Grid>
          </Grid>
        </form>
      </Paper>
    </Container>
  );
}
