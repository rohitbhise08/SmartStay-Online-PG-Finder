import { useEffect, useState } from "react";
import {
  Box,
  Button,
  Chip,
  Container,
  Divider,
  Paper,
  Stack,
  Typography
} from "@mui/material";

import {
  ArrowBackRounded,
  LocationOnRounded,
  WifiRounded,
  RestaurantRounded,
  LocalParkingRounded,
  AcUnitRounded,
  LocalLaundryServiceRounded,
  SecurityRounded,
  KingBedRounded,
  CheckCircleRounded
} from "@mui/icons-material";

import { Link, useNavigate, useParams } from "react-router-dom";

import axios from "../../api/axiosInstance";
import { API } from "../../api/apiEndpoints";

import Loader from "../../components/common/Loader";
import ErrorMessage from "../../components/common/ErrorMessage";

import { useAuth } from "../../context/AuthContext";

const fallback =
  "https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=1200&q=85";

export default function PGDetails() {

  const { id } = useParams();
  const navigate = useNavigate();

  const { isAuthenticated } = useAuth();

  const [pg, setPg] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {

    axios
      .get(API.PGS.BY_ID(id))
      .then((r) => setPg(r.data?.data || r.data))
      .catch(setError);

  }, [id]);

  if (!pg && !error) {
    return <Loader fullPage />;
  }

  if (error) {
    return (
      <Container sx={{ py: 5 }}>
        <ErrorMessage error={error} />
      </Container>
    );
  }

  const rent = pg.monthlyRent ?? pg.rent ?? 0;

  const image =
    pg.imageUrl ||
    pg.image ||
    pg.photoUrl ||
    fallback;

  const availableBeds =
    pg.availableBeds ?? 0;

  const bookNow = () => {

    if (isAuthenticated) {
      navigate(`/bookings/new?pgId=${id}`);
    } else {
      navigate("/login", {
        state: {
          from: `/bookings/new?pgId=${id}`
        }
      });
    }

  };

  return (
    <Box
      sx={{
        bgcolor: "#f8fafc",
        minHeight: "calc(100vh - 74px)",
        py: { xs: 3, md: 5 }
      }}
    >

      <Container maxWidth="xl">

        {/* BACK BUTTON */}

        <Button
          startIcon={<ArrowBackRounded />}
          component={Link}
          to="/pgs"
          sx={{
            mb: 3,
            fontWeight: 700,
            textTransform: "none"
          }}
        >
          Back to PGs
        </Button>

        {/* =====================================================
            MAIN PROPERTY
        ===================================================== */}

        <Box
          sx={{
            display: "grid",
            gridTemplateColumns: {
              xs: "1fr",
              md: "1.5fr 1fr"
            },
            gap: 4,
            alignItems: "start"
          }}
        >

          {/* IMAGE */}

          <Box>

            <Box
              component="img"
              src={image}
              alt={pg.name || "PG"}
              sx={{
                width: "100%",
                height: {
                  xs: 300,
                  sm: 420,
                  md: 550
                },
                objectFit: "cover",
                borderRadius: 4,
                display: "block"
              }}
            />

          </Box>

          {/* DETAILS */}

          <Paper
            elevation={0}
            sx={{
              p: { xs: 2.5, md: 4 },
              borderRadius: 4,
              border: "1px solid #e5e7eb",
              bgcolor: "white"
            }}
          >

            {/* STATUS */}

            <Stack
              direction="row"
              justifyContent="space-between"
              alignItems="center"
              gap={2}
            >

              <Chip
                size="small"
                label={
                  pg.status === "ACTIVE"
                    ? "Available"
                    : String(
                        pg.status || "AVAILABLE"
                      ).replaceAll("_", " ")
                }
                color={
                  pg.status === "ACTIVE"
                    ? "success"
                    : "warning"
                }
              />

              {pg.propertyType && (
                <Chip
                  size="small"
                  variant="outlined"
                  label={pg.propertyType}
                />
              )}

            </Stack>

            {/* NAME */}

            <Typography
              sx={{
                fontSize: {
                  xs: 32,
                  md: 42
                },
                fontWeight: 900,
                lineHeight: 1.1,
                mt: 2
              }}
            >
              {pg.name || "PG Details"}
            </Typography>

            {/* LOCATION */}

            <Typography
              color="text.secondary"
              sx={{
                display: "flex",
                alignItems: "center",
                gap: 0.5,
                mt: 1.5
              }}
            >
              <LocationOnRounded color="primary" />

              {pg.address
                ? pg.address
                : `${pg.area ? `${pg.area}, ` : ""}${pg.city || "Location"}`}
            </Typography>

            {/* RENT */}

            <Box sx={{ mt: 3 }}>

              <Typography
                sx={{
                  fontSize: 34,
                  fontWeight: 900,
                  color: "primary.main"
                }}
              >
                ₹{Number(rent).toLocaleString()}

                <Typography
                  component="span"
                  color="text.secondary"
                  fontSize={15}
                  fontWeight={500}
                >
                  {" "}
                  / month
                </Typography>
              </Typography>

            </Box>

            <Divider sx={{ my: 3 }} />

            {/* PROPERTY INFORMATION */}

            <Typography
              fontWeight={900}
              fontSize={18}
            >
              Property Information
            </Typography>

            <Box
              sx={{
                display: "grid",
                gridTemplateColumns: "1fr 1fr",
                gap: 2,
                mt: 2
              }}
            >

              <Box>
                <Typography
                  fontSize={13}
                  color="text.secondary"
                >
                  Available Beds
                </Typography>

                <Typography
                  fontWeight={800}
                  sx={{
                    display: "flex",
                    alignItems: "center",
                    gap: 0.5,
                    mt: 0.5
                  }}
                >
                  <KingBedRounded
                    fontSize="small"
                    color="primary"
                  />

                  {availableBeds}
                </Typography>
              </Box>

              <Box>
                <Typography
                  fontSize={13}
                  color="text.secondary"
                >
                  Gender Preference
                </Typography>

                <Typography
                  fontWeight={800}
                  sx={{ mt: 0.5 }}
                >
                  {pg.genderPreference || "Not specified"}
                </Typography>
              </Box>

              <Box>
                <Typography
                  fontSize={13}
                  color="text.secondary"
                >
                  Total Beds
                </Typography>

                <Typography
                  fontWeight={800}
                  sx={{ mt: 0.5 }}
                >
                  {pg.totalBeds || "-"}
                </Typography>
              </Box>

              <Box>
                <Typography
                  fontSize={13}
                  color="text.secondary"
                >
                  Furnished
                </Typography>

                <Typography
                  fontWeight={800}
                  sx={{ mt: 0.5 }}
                >
                  {pg.furnished ? "Yes" : "No"}
                </Typography>
              </Box>

            </Box>

            {/* BOOK BUTTON */}

            <Button
              fullWidth
              size="large"
              variant="contained"
              onClick={bookNow}
              sx={{
                mt: 4,
                py: 1.5,
                borderRadius: 2.5,
                fontWeight: 900,
                textTransform: "none",
                fontSize: 16
              }}
            >
              Book This PG
            </Button>

          </Paper>

        </Box>

        {/* =====================================================
            ABOUT + AMENITIES
        ===================================================== */}

        <Box
          sx={{
            display: "grid",
            gridTemplateColumns: {
              xs: "1fr",
              md: "1.2fr 1fr"
            },
            gap: 4,
            mt: 5
          }}
        >

          {/* ABOUT */}

          <Paper
            elevation={0}
            sx={{
              p: { xs: 2.5, md: 4 },
              borderRadius: 4,
              border: "1px solid #e5e7eb"
            }}
          >

            <Typography
              fontSize={22}
              fontWeight={900}
            >
              About this PG
            </Typography>

            <Typography
              color="text.secondary"
              sx={{
                mt: 2,
                lineHeight: 1.8
              }}
            >
              {pg.description ||
                "Comfortable accommodation with essential amenities for students and working professionals."}
            </Typography>

            <Divider sx={{ my: 3 }} />

            <Typography
              fontSize={18}
              fontWeight={900}
            >
              Property Details
            </Typography>

            <Stack spacing={1.5} sx={{ mt: 2 }}>

              {pg.acAvailable && (
                <Typography
                  sx={{
                    display: "flex",
                    alignItems: "center",
                    gap: 1
                  }}
                >
                  <CheckCircleRounded
                    color="success"
                    fontSize="small"
                  />
                  Air Conditioning Available
                </Typography>
              )}

              {pg.foodAvailable && (
                <Typography
                  sx={{
                    display: "flex",
                    alignItems: "center",
                    gap: 1
                  }}
                >
                  <CheckCircleRounded
                    color="success"
                    fontSize="small"
                  />
                  Food Available
                </Typography>
              )}

              {pg.powerBackup && (
                <Typography
                  sx={{
                    display: "flex",
                    alignItems: "center",
                    gap: 1
                  }}
                >
                  <CheckCircleRounded
                    color="success"
                    fontSize="small"
                  />
                  Power Backup
                </Typography>
              )}

            </Stack>

          </Paper>

          {/* AMENITIES */}

          <Paper
            elevation={0}
            sx={{
              p: { xs: 2.5, md: 4 },
              borderRadius: 4,
              border: "1px solid #e5e7eb"
            }}
          >

            <Typography
              fontSize={22}
              fontWeight={900}
            >
              Amenities
            </Typography>

            <Box
              sx={{
                display: "grid",
                gridTemplateColumns: {
                  xs: "1fr 1fr",
                  sm: "repeat(2, 1fr)"
                },
                gap: 1.5,
                mt: 3
              }}
            >

              {pg.wifiAvailable && (
                <Chip
                  icon={<WifiRounded />}
                  label="Wi-Fi"
                  variant="outlined"
                  sx={{
                    justifyContent: "flex-start",
                    py: 2.5
                  }}
                />
              )}

              {pg.foodAvailable && (
                <Chip
                  icon={<RestaurantRounded />}
                  label="Food"
                  variant="outlined"
                  sx={{
                    justifyContent: "flex-start",
                    py: 2.5
                  }}
                />
              )}

              {pg.parkingAvailable && (
                <Chip
                  icon={<LocalParkingRounded />}
                  label="Parking"
                  variant="outlined"
                  sx={{
                    justifyContent: "flex-start",
                    py: 2.5
                  }}
                />
              )}

              {pg.acAvailable && (
                <Chip
                  icon={<AcUnitRounded />}
                  label="AC"
                  variant="outlined"
                  sx={{
                    justifyContent: "flex-start",
                    py: 2.5
                  }}
                />
              )}

              {pg.laundryAvailable && (
                <Chip
                  icon={<LocalLaundryServiceRounded />}
                  label="Laundry"
                  variant="outlined"
                  sx={{
                    justifyContent: "flex-start",
                    py: 2.5
                  }}
                />
              )}

              {pg.securityAvailable && (
                <Chip
                  icon={<SecurityRounded />}
                  label="Security"
                  variant="outlined"
                  sx={{
                    justifyContent: "flex-start",
                    py: 2.5
                  }}
                />
              )}

            </Box>

          </Paper>

        </Box>

      </Container>

    </Box>
  );
}