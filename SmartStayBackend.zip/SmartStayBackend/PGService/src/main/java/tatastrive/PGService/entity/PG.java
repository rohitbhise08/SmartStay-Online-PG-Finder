package tatastrive.PGService.entity;

import jakarta.persistence.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "pgs")
public class PG {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /*
     * ID of the owner from Auth/User Service.
     */
    @Column(nullable = false)
    private Long ownerId;

    @Column(nullable = false)
    private String name;

    @Column(length = 2000)
    private String description;

    private String propertyType;

    @Column(nullable = false)
    private String address;

    @Column(nullable = false)
    private String city;

    private String area;

    private Double latitude;

    private Double longitude;

    @Column(nullable = false)
    private Double monthlyRent;

    private Double securityDeposit;

    private Integer totalBeds;

    private Integer availableBeds;

    private String genderPreference;

    private Boolean foodAvailable;

    private String foodType;

    private Boolean furnished;

    private Boolean acAvailable;

    private Boolean wifiAvailable;

    private Boolean parkingAvailable;

    private Boolean laundryAvailable;

    private Boolean powerBackup;

    private Boolean securityAvailable;

    @Enumerated(EnumType.STRING)
    private PGStatus status;

    private LocalDateTime createdAt;

    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() {

        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();

        if (status == null) {
            status = PGStatus.PENDING_APPROVAL;
        }
    }

    @PreUpdate
    protected void onUpdate() {

        updatedAt = LocalDateTime.now();
    }

    public PG() {
    }

    public Long getId() {
        return id;
    }

    public Long getOwnerId() {
        return ownerId;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public String getPropertyType() {
        return propertyType;
    }

    public String getAddress() {
        return address;
    }

    public String getCity() {
        return city;
    }

    public String getArea() {
        return area;
    }

    public Double getLatitude() {
        return latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public Double getMonthlyRent() {
        return monthlyRent;
    }

    public Double getSecurityDeposit() {
        return securityDeposit;
    }

    public Integer getTotalBeds() {
        return totalBeds;
    }

    public Integer getAvailableBeds() {
        return availableBeds;
    }

    public String getGenderPreference() {
        return genderPreference;
    }

    public Boolean getFoodAvailable() {
        return foodAvailable;
    }

    public String getFoodType() {
        return foodType;
    }

    public Boolean getFurnished() {
        return furnished;
    }

    public Boolean getAcAvailable() {
        return acAvailable;
    }

    public Boolean getWifiAvailable() {
        return wifiAvailable;
    }

    public Boolean getParkingAvailable() {
        return parkingAvailable;
    }

    public Boolean getLaundryAvailable() {
        return laundryAvailable;
    }

    public Boolean getPowerBackup() {
        return powerBackup;
    }

    public Boolean getSecurityAvailable() {
        return securityAvailable;
    }

    public PGStatus getStatus() {
        return status;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setOwnerId(Long ownerId) {
        this.ownerId = ownerId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setPropertyType(String propertyType) {
        this.propertyType = propertyType;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public void setMonthlyRent(Double monthlyRent) {
        this.monthlyRent = monthlyRent;
    }

    public void setSecurityDeposit(Double securityDeposit) {
        this.securityDeposit = securityDeposit;
    }

    public void setTotalBeds(Integer totalBeds) {
        this.totalBeds = totalBeds;
    }

    public void setAvailableBeds(Integer availableBeds) {
        this.availableBeds = availableBeds;
    }

    public void setGenderPreference(String genderPreference) {
        this.genderPreference = genderPreference;
    }

    public void setFoodAvailable(Boolean foodAvailable) {
        this.foodAvailable = foodAvailable;
    }

    public void setFoodType(String foodType) {
        this.foodType = foodType;
    }

    public void setFurnished(Boolean furnished) {
        this.furnished = furnished;
    }

    public void setAcAvailable(Boolean acAvailable) {
        this.acAvailable = acAvailable;
    }

    public void setWifiAvailable(Boolean wifiAvailable) {
        this.wifiAvailable = wifiAvailable;
    }

    public void setParkingAvailable(Boolean parkingAvailable) {
        this.parkingAvailable = parkingAvailable;
    }

    public void setLaundryAvailable(Boolean laundryAvailable) {
        this.laundryAvailable = laundryAvailable;
    }

    public void setPowerBackup(Boolean powerBackup) {
        this.powerBackup = powerBackup;
    }

    public void setSecurityAvailable(Boolean securityAvailable) {
        this.securityAvailable = securityAvailable;
    }

    public void setStatus(PGStatus status) {
        this.status = status;
    }
}