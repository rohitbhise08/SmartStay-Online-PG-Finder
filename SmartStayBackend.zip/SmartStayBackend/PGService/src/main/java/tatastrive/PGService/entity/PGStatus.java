package tatastrive.PGService.entity;

public enum PGStatus {

    PENDING_APPROVAL,
    ACTIVE,
    INACTIVE,
    REJECTED
}