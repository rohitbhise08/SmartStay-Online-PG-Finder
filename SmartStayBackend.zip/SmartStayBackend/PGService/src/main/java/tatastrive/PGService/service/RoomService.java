package tatastrive.PGService.service;

import tatastrive.PGService.entity.Room;

import java.util.List;

public interface RoomService {

    Room createRoom(Room room);

    Room getRoomById(Long id);

    List<Room> getRoomsByPG(Long pgId);

    List<Room> getAvailableRooms(Long pgId);

    Room updateRoom(Long id, Room room);

    void deleteRoom(Long id);
}