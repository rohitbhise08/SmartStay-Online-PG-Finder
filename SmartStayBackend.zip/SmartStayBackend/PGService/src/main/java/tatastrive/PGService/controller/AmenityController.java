package tatastrive.PGService.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import tatastrive.PGService.entity.Amenity;
import tatastrive.PGService.service.AmenityService;

import java.util.List;

@RestController
@RequestMapping("/amenities")
public class AmenityController {

    private final AmenityService amenityService;

    public AmenityController(
            AmenityService amenityService) {

        this.amenityService = amenityService;
    }

    @PostMapping
    public ResponseEntity<Amenity> createAmenity(
            @RequestBody Amenity amenity) {

        return new ResponseEntity<>(
                amenityService.createAmenity(
                        amenity
                ),
                HttpStatus.CREATED
        );
    }

    @GetMapping("/pg/{pgId}")
    public ResponseEntity<List<Amenity>>
    getAmenities(@PathVariable Long pgId) {

        return ResponseEntity.ok(
                amenityService.getAmenitiesByPG(
                        pgId
                )
        );
    }

    @PutMapping("/{id}")
    public ResponseEntity<Amenity> updateAmenity(
            @PathVariable Long id,
            @RequestBody Amenity amenity) {

        return ResponseEntity.ok(
                amenityService.updateAmenity(
                        id,
                        amenity
                )
        );
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteAmenity(
            @PathVariable Long id) {

        amenityService.deleteAmenity(id);

        return ResponseEntity.ok(
                "Amenity deleted successfully"
        );
    }
}