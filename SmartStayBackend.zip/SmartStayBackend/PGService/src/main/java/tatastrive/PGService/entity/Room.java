package tatastrive.PGService.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "rooms")
public class Room {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private Long pgId;

    @Column(nullable = false)
    private String roomNumber;

    private String roomType;

    private Integer capacity;

    private Integer occupied;

    private Double rent;

    private Boolean available;

    public Room() {
    }

    public Long getId() {
        return id;
    }

    public Long getPgId() {
        return pgId;
    }

    public String getRoomNumber() {
        return roomNumber;
    }

    public String getRoomType() {
        return roomType;
    }

    public Integer getCapacity() {
        return capacity;
    }

    public Integer getOccupied() {
        return occupied;
    }

    public Double getRent() {
        return rent;
    }

    public Boolean getAvailable() {
        return available;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setPgId(Long pgId) {
        this.pgId = pgId;
    }

    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }

    public void setRoomType(String roomType) {
        this.roomType = roomType;
    }

    public void setCapacity(Integer capacity) {
        this.capacity = capacity;
    }

    public void setOccupied(Integer occupied) {
        this.occupied = occupied;
    }

    public void setRent(Double rent) {
        this.rent = rent;
    }

    public void setAvailable(Boolean available) {
        this.available = available;
    }
}