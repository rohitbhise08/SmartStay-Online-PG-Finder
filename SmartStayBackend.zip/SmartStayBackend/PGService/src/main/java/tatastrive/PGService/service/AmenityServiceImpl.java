package tatastrive.PGService.service;

import org.springframework.stereotype.Service;
import tatastrive.PGService.entity.Amenity;
import tatastrive.PGService.exception.ResourceNotFoundException;
import tatastrive.PGService.repository.AmenityRepository;

import java.util.List;

@Service
public class AmenityServiceImpl implements AmenityService {

    private final AmenityRepository repository;

    public AmenityServiceImpl(
            AmenityRepository repository) {

        this.repository = repository;
    }

    @Override
    public Amenity createAmenity(Amenity amenity) {

        return repository.save(amenity);
    }

    @Override
    public List<Amenity> getAmenitiesByPG(Long pgId) {

        return repository.findByPgId(pgId);
    }

    @Override
    public Amenity updateAmenity(
            Long id,
            Amenity amenity) {

        Amenity existing = repository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Amenity not found with id: " + id
                        )
                );

        existing.setName(amenity.getName());
        existing.setDescription(
                amenity.getDescription()
        );
        existing.setAvailable(
                amenity.getAvailable()
        );

        return repository.save(existing);
    }

    @Override
    public void deleteAmenity(Long id) {

        Amenity amenity = repository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Amenity not found with id: " + id
                        )
                );

        repository.delete(amenity);
    }
}