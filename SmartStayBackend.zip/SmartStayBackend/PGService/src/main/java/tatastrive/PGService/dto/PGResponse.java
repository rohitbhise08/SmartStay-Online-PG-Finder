package tatastrive.PGService.dto;

public class PGResponse {
}
