package tatastrive.PGService.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import tatastrive.PGService.entity.Room;

import java.util.List;

public interface RoomRepository
        extends JpaRepository<Room, Long> {

    List<Room> findByPgId(Long pgId);

    List<Room> findByPgIdAndAvailable(
            Long pgId,
            Boolean available
    );
}