package tatastrive.PGService.service;

import org.springframework.stereotype.Service;
import tatastrive.PGService.entity.Room;
import tatastrive.PGService.exception.ResourceNotFoundException;
import tatastrive.PGService.repository.RoomRepository;

import java.util.List;

@Service
public class RoomServiceImpl implements RoomService {

    private final RoomRepository roomRepository;

    public RoomServiceImpl(RoomRepository roomRepository) {
        this.roomRepository = roomRepository;
    }

    @Override
    public Room createRoom(Room room) {

        if (room.getOccupied() == null) {
            room.setOccupied(0);
        }

        if (room.getAvailable() == null) {
            room.setAvailable(true);
        }

        return roomRepository.save(room);
    }

    @Override
    public Room getRoomById(Long id) {

        return roomRepository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Room not found with id: " + id
                        )
                );
    }

    @Override
    public List<Room> getRoomsByPG(Long pgId) {

        return roomRepository.findByPgId(pgId);
    }

    @Override
    public List<Room> getAvailableRooms(Long pgId) {

        return roomRepository
                .findByPgIdAndAvailable(
                        pgId,
                        true
                );
    }

    @Override
    public Room updateRoom(
            Long id,
            Room room) {

        Room existingRoom = getRoomById(id);

        existingRoom.setRoomNumber(
                room.getRoomNumber()
        );

        existingRoom.setRoomType(
                room.getRoomType()
        );

        existingRoom.setCapacity(
                room.getCapacity()
        );

        existingRoom.setOccupied(
                room.getOccupied()
        );

        existingRoom.setRent(
                room.getRent()
        );

        existingRoom.setAvailable(
                room.getAvailable()
        );

        return roomRepository.save(existingRoom);
    }

    @Override
    public void deleteRoom(Long id) {

        Room room = getRoomById(id);

        roomRepository.delete(room);
    }
}