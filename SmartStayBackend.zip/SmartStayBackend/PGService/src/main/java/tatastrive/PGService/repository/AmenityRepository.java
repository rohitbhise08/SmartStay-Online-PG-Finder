package tatastrive.PGService.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import tatastrive.PGService.entity.Amenity;

import java.util.List;

public interface AmenityRepository
        extends JpaRepository<Amenity, Long> {

    List<Amenity> findByPgId(Long pgId);
}