package tatastrive.PGService.service;

import tatastrive.PGService.entity.PG;
import tatastrive.PGService.entity.PGStatus;

import java.util.List;

public interface PGService {

    PG createPG(PG pg);

    PG getPGById(Long id);

    List<PG> getAllPGs();

    List<PG> getPGsByCity(String city);

    List<PG> getPGsByArea(String area);

    List<PG> getPGsByOwner(Long ownerId);

    List<PG> searchPGs(
            String city,
            Double minRent,
            Double maxRent
    );

    PG updatePG(Long id, PG pg);

    PG updateStatus(Long id, PGStatus status);

    void deletePG(Long id);

    void reserveBeds(Long pgId, Integer count);

    void releaseBeds(Long pgId, Integer count);
}