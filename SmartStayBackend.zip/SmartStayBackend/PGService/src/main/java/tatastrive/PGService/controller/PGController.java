package tatastrive.PGService.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import tatastrive.PGService.entity.PG;
import tatastrive.PGService.entity.PGStatus;
import tatastrive.PGService.service.PGService;

import java.util.List;

@RestController
@RequestMapping("/pgs")
public class PGController {

    private final PGService pgService;

    public PGController(PGService pgService) {

        this.pgService = pgService;
    }

    @PostMapping
    public ResponseEntity<PG> createPG(
            @RequestBody PG pg) {

        return new ResponseEntity<>(
                pgService.createPG(pg),
                HttpStatus.CREATED
        );
    }

    @GetMapping
    public ResponseEntity<List<PG>> getAllPGs() {

        return ResponseEntity.ok(
                pgService.getAllPGs()
        );
    }

    @GetMapping("/{id}")
    public ResponseEntity<PG> getPG(
            @PathVariable Long id) {

        return ResponseEntity.ok(
                pgService.getPGById(id)
        );
    }

    @GetMapping("/city/{city}")
    public ResponseEntity<List<PG>> getByCity(
            @PathVariable String city) {

        return ResponseEntity.ok(
                pgService.getPGsByCity(city)
        );
    }

    @GetMapping("/area/{area}")
    public ResponseEntity<List<PG>> getByArea(
            @PathVariable String area) {

        return ResponseEntity.ok(
                pgService.getPGsByArea(area)
        );
    }

    @GetMapping("/owner/{ownerId}")
    public ResponseEntity<List<PG>> getByOwner(
            @PathVariable Long ownerId) {

        return ResponseEntity.ok(
                pgService.getPGsByOwner(ownerId)
        );
    }

    @GetMapping("/search")
    public ResponseEntity<List<PG>> searchPGs(
            @RequestParam(required = false)
            String city,

            @RequestParam(required = false)
            Double minRent,

            @RequestParam(required = false)
            Double maxRent) {

        return ResponseEntity.ok(
                pgService.searchPGs(
                        city,
                        minRent,
                        maxRent
                )
        );
    }

    @PutMapping("/{id}")
    public ResponseEntity<PG> updatePG(
            @PathVariable Long id,
            @RequestBody PG pg) {

        return ResponseEntity.ok(
                pgService.updatePG(id, pg)
        );
    }

    @PatchMapping("/{id}/status")
    public ResponseEntity<PG> updateStatus(
            @PathVariable Long id,
            @RequestParam PGStatus status) {

        return ResponseEntity.ok(
                pgService.updateStatus(
                        id,
                        status
                )
        );
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deletePG(
            @PathVariable Long id) {

        pgService.deletePG(id);

        return ResponseEntity.ok(
                "PG deleted successfully"
        );
    }

    @PostMapping("/{id}/beds/reserve")
    public ResponseEntity<String> reserveBeds(
            @PathVariable Long id,
            @RequestParam Integer count) {

        pgService.reserveBeds(id, count);

        return ResponseEntity.ok(
                count + " bed(s) reserved successfully"
        );
    }

    @PostMapping("/{id}/beds/release")
    public ResponseEntity<String> releaseBeds(
            @PathVariable Long id,
            @RequestParam Integer count) {

        pgService.releaseBeds(id, count);

        return ResponseEntity.ok(
                count + " bed(s) released successfully"
        );
    }


}