package tatastrive.PGService.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import tatastrive.PGService.entity.Room;
import tatastrive.PGService.service.RoomService;

import java.util.List;

@RestController
@RequestMapping("/rooms")
public class RoomController {

    private final RoomService roomService;

    public RoomController(RoomService roomService) {

        this.roomService = roomService;
    }

    @PostMapping
    public ResponseEntity<Room> createRoom(
            @RequestBody Room room) {

        return new ResponseEntity<>(
                roomService.createRoom(room),
                HttpStatus.CREATED
        );
    }

    @GetMapping("/{id}")
    public ResponseEntity<Room> getRoom(
            @PathVariable Long id) {

        return ResponseEntity.ok(
                roomService.getRoomById(id)
        );
    }

    @GetMapping("/pg/{pgId}")
    public ResponseEntity<List<Room>> getRooms(
            @PathVariable Long pgId) {

        return ResponseEntity.ok(
                roomService.getRoomsByPG(pgId)
        );
    }

    @GetMapping("/pg/{pgId}/available")
    public ResponseEntity<List<Room>>
    getAvailableRooms(
            @PathVariable Long pgId) {

        return ResponseEntity.ok(
                roomService.getAvailableRooms(pgId)
        );
    }

    @PutMapping("/{id}")
    public ResponseEntity<Room> updateRoom(
            @PathVariable Long id,
            @RequestBody Room room) {

        return ResponseEntity.ok(
                roomService.updateRoom(
                        id,
                        room
                )
        );
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteRoom(
            @PathVariable Long id) {

        roomService.deleteRoom(id);

        return ResponseEntity.ok(
                "Room deleted successfully"
        );
    }
}