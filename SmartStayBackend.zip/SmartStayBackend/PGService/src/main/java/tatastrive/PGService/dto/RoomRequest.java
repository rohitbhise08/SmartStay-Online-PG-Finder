package tatastrive.PGService.dto;

public class RoomRequest {
}
