package tatastrive.PGService.exception;

public class InsufficientBedsException extends RuntimeException {

    public InsufficientBedsException(String message) {
        super(message);
    }
}