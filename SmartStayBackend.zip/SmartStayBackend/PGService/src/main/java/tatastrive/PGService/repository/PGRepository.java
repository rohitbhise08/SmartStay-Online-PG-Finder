package tatastrive.PGService.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import tatastrive.PGService.entity.PG;
import tatastrive.PGService.entity.PGStatus;

import java.util.List;

public interface PGRepository extends JpaRepository<PG, Long> {

    List<PG> findByCityIgnoreCase(String city);

    List<PG> findByAreaIgnoreCase(String area);

    List<PG> findByOwnerId(Long ownerId);

    List<PG> findByStatus(PGStatus status);

    List<PG> findByMonthlyRentBetween(
            Double minRent,
            Double maxRent
    );

    List<PG> findByCityIgnoreCaseAndMonthlyRentBetween(
            String city,
            Double minRent,
            Double maxRent
    );
}