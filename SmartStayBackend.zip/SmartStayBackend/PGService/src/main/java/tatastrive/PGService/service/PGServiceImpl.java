package tatastrive.PGService.service;

import org.springframework.stereotype.Service;
import tatastrive.PGService.entity.PG;
import tatastrive.PGService.entity.PGStatus;
import tatastrive.PGService.exception.InsufficientBedsException;
import tatastrive.PGService.exception.ResourceNotFoundException;
import tatastrive.PGService.repository.PGRepository;

import java.util.List;

@Service
public class PGServiceImpl implements PGService {

    private final PGRepository pgRepository;

    public PGServiceImpl(PGRepository pgRepository) {
        this.pgRepository = pgRepository;
    }

    @Override
    public PG createPG(PG pg) {

        if (pg.getAvailableBeds() == null) {
            pg.setAvailableBeds(pg.getTotalBeds());
        }

        if (pg.getStatus() == null) {
            pg.setStatus(PGStatus.PENDING_APPROVAL);
        }

        return pgRepository.save(pg);
    }

    @Override
    public PG getPGById(Long id) {

        return pgRepository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "PG not found with id: " + id
                        )
                );
    }

    @Override
    public List<PG> getAllPGs() {

        return pgRepository.findAll();
    }

    @Override
    public List<PG> getPGsByCity(String city) {

        return pgRepository.findByCityIgnoreCase(city);
    }

    @Override
    public List<PG> getPGsByArea(String area) {

        return pgRepository.findByAreaIgnoreCase(area);
    }

    @Override
    public List<PG> getPGsByOwner(Long ownerId) {

        return pgRepository.findByOwnerId(ownerId);
    }

    @Override
    public List<PG> searchPGs(
            String city,
            Double minRent,
            Double maxRent) {

        if (city != null &&
                minRent != null &&
                maxRent != null) {

            return pgRepository
                    .findByCityIgnoreCaseAndMonthlyRentBetween(
                            city,
                            minRent,
                            maxRent
                    );
        }

        if (minRent != null && maxRent != null) {

            return pgRepository
                    .findByMonthlyRentBetween(
                            minRent,
                            maxRent
                    );
        }

        if (city != null) {

            return pgRepository
                    .findByCityIgnoreCase(city);
        }

        return pgRepository.findAll();
    }

    @Override
    public PG updatePG(Long id, PG pg) {

        PG existingPG = getPGById(id);

        existingPG.setName(pg.getName());
        existingPG.setDescription(pg.getDescription());
        existingPG.setPropertyType(pg.getPropertyType());
        existingPG.setAddress(pg.getAddress());
        existingPG.setCity(pg.getCity());
        existingPG.setArea(pg.getArea());
        existingPG.setLatitude(pg.getLatitude());
        existingPG.setLongitude(pg.getLongitude());
        existingPG.setMonthlyRent(pg.getMonthlyRent());
        existingPG.setSecurityDeposit(pg.getSecurityDeposit());
        existingPG.setTotalBeds(pg.getTotalBeds());
        existingPG.setAvailableBeds(pg.getAvailableBeds());
        existingPG.setGenderPreference(pg.getGenderPreference());
        existingPG.setFoodAvailable(pg.getFoodAvailable());
        existingPG.setFoodType(pg.getFoodType());
        existingPG.setFurnished(pg.getFurnished());
        existingPG.setAcAvailable(pg.getAcAvailable());
        existingPG.setWifiAvailable(pg.getWifiAvailable());
        existingPG.setParkingAvailable(pg.getParkingAvailable());
        existingPG.setLaundryAvailable(pg.getLaundryAvailable());
        existingPG.setPowerBackup(pg.getPowerBackup());
        existingPG.setSecurityAvailable(pg.getSecurityAvailable());

        return pgRepository.save(existingPG);
    }

    @Override
    public PG updateStatus(
            Long id,
            PGStatus status) {

        PG pg = getPGById(id);

        pg.setStatus(status);

        return pgRepository.save(pg);
    }

    @Override
    public void deletePG(Long id) {

        PG pg = getPGById(id);

        pgRepository.delete(pg);
    }

    @Override
    public void reserveBeds(Long pgId, Integer count) {

        PG pg = pgRepository.findById(pgId)
                .orElseThrow(() ->
                        new RuntimeException(
                                "PG not found with id: " + pgId
                        )
                );

        if (count == null || count <= 0) {
            throw new RuntimeException(
                    "Bed count must be greater than zero"
            );
        }

        if (pg.getStatus() != PGStatus.ACTIVE) {
            throw new RuntimeException(
                    "Only ACTIVE PGs can be booked"
            );
        }

        if (pg.getAvailableBeds() < count) {
            throw new InsufficientBedsException(
                    "Not enough beds available"
            );
        }

        pg.setAvailableBeds(
                pg.getAvailableBeds() - count
        );

        pgRepository.save(pg);
    }

    @Override
    public void releaseBeds(Long pgId, Integer count) {

        PG pg = pgRepository.findById(pgId)
                .orElseThrow(() ->
                        new RuntimeException(
                                "PG not found with id: " + pgId
                        )
                );

        if (count == null || count <= 0) {
            throw new RuntimeException(
                    "Bed count must be greater than zero"
            );
        }

        int newAvailableBeds =
                pg.getAvailableBeds() + count;

        if (newAvailableBeds > pg.getTotalBeds()) {
            newAvailableBeds = pg.getTotalBeds();
        }

        pg.setAvailableBeds(newAvailableBeds);

        pgRepository.save(pg);
    }
}