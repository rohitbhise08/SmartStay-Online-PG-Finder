package tatastrive.PGService.dto;

public class RoomResponse {
}
