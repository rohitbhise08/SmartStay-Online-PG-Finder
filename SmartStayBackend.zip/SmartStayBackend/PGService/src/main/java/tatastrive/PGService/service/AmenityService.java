package tatastrive.PGService.service;

import tatastrive.PGService.entity.Amenity;

import java.util.List;

public interface AmenityService {

    Amenity createAmenity(Amenity amenity);

    List<Amenity> getAmenitiesByPG(Long pgId);

    Amenity updateAmenity(Long id, Amenity amenity);

    void deleteAmenity(Long id);
}