package tatastrive.PGService.dto;

public class PGRequest {
}
