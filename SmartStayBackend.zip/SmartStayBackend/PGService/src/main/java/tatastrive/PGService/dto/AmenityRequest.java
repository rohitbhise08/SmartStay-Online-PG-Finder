package tatastrive.PGService.dto;

public class AmenityRequest {
}
