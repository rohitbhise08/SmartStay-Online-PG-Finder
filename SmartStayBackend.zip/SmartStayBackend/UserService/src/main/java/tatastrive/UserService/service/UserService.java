package tatastrive.UserService.service;

import tatastrive.UserService.entity.UserPreference;
import tatastrive.UserService.entity.UserProfile;

import java.util.List;

public interface UserService {

    UserProfile createUser(UserProfile userProfile);

    UserProfile getUserById(Long id);

    UserProfile getUserByAuthUserId(Long authUserId);

    List<UserProfile> getAllUsers();

    UserProfile updateUser(Long id, UserProfile userProfile);

    void deleteUser(Long id);

    UserPreference createOrUpdatePreference(
            Long userId,
            UserPreference preference
    );

    UserPreference getPreference(Long userId);
}