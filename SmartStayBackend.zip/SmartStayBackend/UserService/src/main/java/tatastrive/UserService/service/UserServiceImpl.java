package tatastrive.UserService.service;

import org.springframework.stereotype.Service;
import tatastrive.UserService.entity.UserPreference;
import tatastrive.UserService.entity.UserProfile;
import tatastrive.UserService.exception.ResourceNotFoundException;
import tatastrive.UserService.repository.UserPreferenceRepository;
import tatastrive.UserService.repository.UserProfileRepository;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    private final UserProfileRepository userRepository;

    private final UserPreferenceRepository preferenceRepository;

    public UserServiceImpl(
            UserProfileRepository userRepository,
            UserPreferenceRepository preferenceRepository) {

        this.userRepository = userRepository;
        this.preferenceRepository = preferenceRepository;
    }

    @Override
    public UserProfile createUser(UserProfile userProfile) {

        if (userRepository.existsByAuthUserId(
                userProfile.getAuthUserId())) {

            throw new RuntimeException(
                    "User profile already exists for this Auth User"
            );
        }

        if (userRepository.existsByEmail(
                userProfile.getEmail())) {

            throw new RuntimeException(
                    "Email already exists"
            );
        }

        if (userRepository.existsByPhone(
                userProfile.getPhone())) {

            throw new RuntimeException(
                    "Phone number already exists"
            );
        }

        return userRepository.save(userProfile);
    }

    @Override
    public UserProfile getUserById(Long id) {

        return userRepository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "User not found with id: " + id
                        )
                );
    }

    @Override
    public UserProfile getUserByAuthUserId(
            Long authUserId) {

        return userRepository
                .findByAuthUserId(authUserId)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "User profile not found"
                        )
                );
    }

    @Override
    public List<UserProfile> getAllUsers() {

        return userRepository.findAll();
    }

    @Override
    public UserProfile updateUser(
            Long id,
            UserProfile userProfile) {

        UserProfile existingUser = getUserById(id);

        existingUser.setFullName(
                userProfile.getFullName()
        );

        existingUser.setEmail(
                userProfile.getEmail()
        );

        existingUser.setPhone(
                userProfile.getPhone()
        );

        existingUser.setGender(
                userProfile.getGender()
        );

        existingUser.setDateOfBirth(
                userProfile.getDateOfBirth()
        );

        existingUser.setProfileImage(
                userProfile.getProfileImage()
        );

        existingUser.setCity(
                userProfile.getCity()
        );

        existingUser.setAddress(
                userProfile.getAddress()
        );

        existingUser.setOccupation(
                userProfile.getOccupation()
        );

        existingUser.setBio(
                userProfile.getBio()
        );

        return userRepository.save(existingUser);
    }

    @Override
    public void deleteUser(Long id) {

        UserProfile user = getUserById(id);

        preferenceRepository
                .findByUserId(user.getId())
                .ifPresent(preferenceRepository::delete);

        userRepository.delete(user);
    }

    @Override
    public UserPreference createOrUpdatePreference(
            Long userId,
            UserPreference preference) {

        getUserById(userId);

        UserPreference existing =
                preferenceRepository
                        .findByUserId(userId)
                        .orElse(null);

        if (existing != null) {

            existing.setPreferredCity(
                    preference.getPreferredCity()
            );

            existing.setPreferredArea(
                    preference.getPreferredArea()
            );

            existing.setMinRent(
                    preference.getMinRent()
            );

            existing.setMaxRent(
                    preference.getMaxRent()
            );

            existing.setRoomType(
                    preference.getRoomType()
            );

            existing.setFoodPreference(
                    preference.getFoodPreference()
            );

            existing.setPreferredGender(
                    preference.getPreferredGender()
            );

            existing.setFurnished(
                    preference.getFurnished()
            );

            existing.setAcRequired(
                    preference.getAcRequired()
            );

            existing.setAttachedBathroom(
                    preference.getAttachedBathroom()
            );

            existing.setWifiRequired(
                    preference.getWifiRequired()
            );

            existing.setParkingRequired(
                    preference.getParkingRequired()
            );

            return preferenceRepository.save(existing);
        }

        preference.setUserId(userId);

        return preferenceRepository.save(preference);
    }

    @Override
    public UserPreference getPreference(Long userId) {

        getUserById(userId);

        return preferenceRepository
                .findByUserId(userId)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Preferences not found"
                        )
                );
    }
}