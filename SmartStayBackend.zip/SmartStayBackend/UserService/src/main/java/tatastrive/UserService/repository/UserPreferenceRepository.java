package tatastrive.UserService.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import tatastrive.UserService.entity.UserPreference;

import java.util.Optional;

public interface UserPreferenceRepository
        extends JpaRepository<UserPreference, Long> {

    Optional<UserPreference> findByUserId(Long userId);

    boolean existsByUserId(Long userId);
}