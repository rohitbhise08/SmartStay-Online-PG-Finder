package tatastrive.UserService.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import tatastrive.UserService.entity.UserPreference;
import tatastrive.UserService.entity.UserProfile;
import tatastrive.UserService.service.UserService;

import java.util.List;

@RestController
@RequestMapping("/users")
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {

        this.userService = userService;
    }

    // =========================
    // USER PROFILE
    // =========================

    @PostMapping
    public ResponseEntity<UserProfile> createUser(
            @RequestBody UserProfile userProfile) {

        return new ResponseEntity<>(
                userService.createUser(userProfile),
                HttpStatus.CREATED
        );
    }

    @GetMapping("/{id}")
    public ResponseEntity<UserProfile> getUser(
            @PathVariable Long id) {

        return ResponseEntity.ok(
                userService.getUserById(id)
        );
    }

    @GetMapping
    public ResponseEntity<List<UserProfile>> getAllUsers() {

        return ResponseEntity.ok(
                userService.getAllUsers()
        );
    }

    @GetMapping("/auth/{authUserId}")
    public ResponseEntity<UserProfile> getUserByAuthId(
            @PathVariable Long authUserId) {

        return ResponseEntity.ok(
                userService.getUserByAuthUserId(authUserId)
        );
    }

    @PutMapping("/{id}")
    public ResponseEntity<UserProfile> updateUser(
            @PathVariable Long id,
            @RequestBody UserProfile userProfile) {

        return ResponseEntity.ok(
                userService.updateUser(
                        id,
                        userProfile
                )
        );
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteUser(
            @PathVariable Long id) {

        userService.deleteUser(id);

        return ResponseEntity.ok(
                "User deleted successfully"
        );
    }

    // =========================
    // USER PREFERENCES
    // =========================

    @PostMapping("/{userId}/preferences")
    public ResponseEntity<UserPreference> savePreference(
            @PathVariable Long userId,
            @RequestBody UserPreference preference) {

        return ResponseEntity.ok(
                userService.createOrUpdatePreference(
                        userId,
                        preference
                )
        );
    }

    @GetMapping("/{userId}/preferences")
    public ResponseEntity<UserPreference> getPreference(
            @PathVariable Long userId) {

        return ResponseEntity.ok(
                userService.getPreference(userId)
        );
    }
}