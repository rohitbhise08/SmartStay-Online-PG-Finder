package tatastrive.UserService.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import tatastrive.UserService.entity.UserProfile;

import java.util.Optional;

public interface UserProfileRepository
        extends JpaRepository<UserProfile, Long> {

    Optional<UserProfile> findByAuthUserId(Long authUserId);

    Optional<UserProfile> findByEmail(String email);

    boolean existsByAuthUserId(Long authUserId);

    boolean existsByEmail(String email);

    boolean existsByPhone(String phone);
}