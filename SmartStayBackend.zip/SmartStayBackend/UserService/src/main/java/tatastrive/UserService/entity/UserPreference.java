package tatastrive.UserService.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "user_preferences")
public class UserPreference {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "user_id", nullable = false, unique = true)
    private Long userId;

    private String preferredCity;

    private String preferredArea;

    private Double minRent;

    private Double maxRent;

    private String roomType;

    private String foodPreference;

    private String preferredGender;

    private Boolean furnished;

    private Boolean acRequired;

    private Boolean attachedBathroom;

    private Boolean wifiRequired;

    private Boolean parkingRequired;

    public UserPreference() {
    }

    public Long getId() {
        return id;
    }

    public Long getUserId() {
        return userId;
    }

    public String getPreferredCity() {
        return preferredCity;
    }

    public String getPreferredArea() {
        return preferredArea;
    }

    public Double getMinRent() {
        return minRent;
    }

    public Double getMaxRent() {
        return maxRent;
    }

    public String getRoomType() {
        return roomType;
    }

    public String getFoodPreference() {
        return foodPreference;
    }

    public String getPreferredGender() {
        return preferredGender;
    }

    public Boolean getFurnished() {
        return furnished;
    }

    public Boolean getAcRequired() {
        return acRequired;
    }

    public Boolean getAttachedBathroom() {
        return attachedBathroom;
    }

    public Boolean getWifiRequired() {
        return wifiRequired;
    }

    public Boolean getParkingRequired() {
        return parkingRequired;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public void setPreferredCity(String preferredCity) {
        this.preferredCity = preferredCity;
    }

    public void setPreferredArea(String preferredArea) {
        this.preferredArea = preferredArea;
    }

    public void setMinRent(Double minRent) {
        this.minRent = minRent;
    }

    public void setMaxRent(Double maxRent) {
        this.maxRent = maxRent;
    }

    public void setRoomType(String roomType) {
        this.roomType = roomType;
    }

    public void setFoodPreference(String foodPreference) {
        this.foodPreference = foodPreference;
    }

    public void setPreferredGender(String preferredGender) {
        this.preferredGender = preferredGender;
    }

    public void setFurnished(Boolean furnished) {
        this.furnished = furnished;
    }

    public void setAcRequired(Boolean acRequired) {
        this.acRequired = acRequired;
    }

    public void setAttachedBathroom(Boolean attachedBathroom) {
        this.attachedBathroom = attachedBathroom;
    }

    public void setWifiRequired(Boolean wifiRequired) {
        this.wifiRequired = wifiRequired;
    }

    public void setParkingRequired(Boolean parkingRequired) {
        this.parkingRequired = parkingRequired;
    }
}