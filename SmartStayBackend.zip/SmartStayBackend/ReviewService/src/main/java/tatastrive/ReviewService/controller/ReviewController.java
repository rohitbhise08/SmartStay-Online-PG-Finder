package tatastrive.ReviewService.controller;

import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import tatastrive.ReviewService.entity.Review;
import tatastrive.ReviewService.service.ReviewService;

import java.util.List;

@RestController
@RequestMapping("/reviews")
@CrossOrigin(origins = "*")
public class ReviewController {

    private final ReviewService reviewService;

    public ReviewController(ReviewService reviewService) {
        this.reviewService = reviewService;
    }

    // Add Review
    @PostMapping
    public ResponseEntity<Review> addReview(
            @Valid @RequestBody Review review) {

        return new ResponseEntity<>(
                reviewService.addReview(review),
                HttpStatus.CREATED
        );
    }

    // Get all reviews
    @GetMapping
    public ResponseEntity<List<Review>> getAllReviews() {

        return ResponseEntity.ok(
                reviewService.getAllReviews()
        );
    }

    // Get review by ID
    @GetMapping("/{id}")
    public ResponseEntity<Review> getReviewById(
            @PathVariable Long id) {

        return ResponseEntity.ok(
                reviewService.getReviewById(id)
        );
    }

    // Get reviews for a PG
    @GetMapping("/pg/{pgId}")
    public ResponseEntity<List<Review>> getReviewsByPgId(
            @PathVariable Long pgId) {

        return ResponseEntity.ok(
                reviewService.getReviewsByPgId(pgId)
        );
    }

    // Get reviews by user
    @GetMapping("/user/{userId}")
    public ResponseEntity<List<Review>> getReviewsByUserId(
            @PathVariable Long userId) {

        return ResponseEntity.ok(
                reviewService.getReviewsByUserId(userId)
        );
    }

    // Get average rating
    @GetMapping("/pg/{pgId}/average")
    public ResponseEntity<Double> getAverageRating(
            @PathVariable Long pgId) {

        return ResponseEntity.ok(
                reviewService.getAverageRating(pgId)
        );
    }

    // Update review
    @PutMapping("/{id}")
    public ResponseEntity<Review> updateReview(
            @PathVariable Long id,
            @Valid @RequestBody Review review) {

        return ResponseEntity.ok(
                reviewService.updateReview(id, review)
        );
    }

    // Delete review
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteReview(
            @PathVariable Long id) {

        reviewService.deleteReview(id);

        return ResponseEntity.ok(
                "Review deleted successfully"
        );
    }
}