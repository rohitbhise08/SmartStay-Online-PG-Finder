package tatastrive.ReviewService.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import tatastrive.ReviewService.entity.Review;

import java.util.List;

public interface ReviewRepository extends JpaRepository<Review, Long> {

    List<Review> findByPgId(Long pgId);

    List<Review> findByUserId(Long userId);

    boolean existsByUserIdAndPgId(Long userId, Long pgId);
}