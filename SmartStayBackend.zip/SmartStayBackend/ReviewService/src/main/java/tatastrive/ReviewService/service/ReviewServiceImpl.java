package tatastrive.ReviewService.service;

import org.springframework.stereotype.Service;
import tatastrive.ReviewService.entity.Review;
import tatastrive.ReviewService.repository.ReviewRepository;

import java.util.List;

@Service
public class ReviewServiceImpl implements ReviewService {

    private final ReviewRepository reviewRepository;

    public ReviewServiceImpl(ReviewRepository reviewRepository) {
        this.reviewRepository = reviewRepository;
    }

    @Override
    public Review addReview(Review review) {

        if (reviewRepository.existsByUserIdAndPgId(
                review.getUserId(),
                review.getPgId())) {

            throw new RuntimeException(
                    "User has already reviewed this PG"
            );
        }

        return reviewRepository.save(review);
    }

    @Override
    public List<Review> getAllReviews() {
        return reviewRepository.findAll();
    }

    @Override
    public Review getReviewById(Long id) {

        return reviewRepository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException(
                                "Review not found with ID: " + id
                        ));
    }

    @Override
    public List<Review> getReviewsByPgId(Long pgId) {
        return reviewRepository.findByPgId(pgId);
    }

    @Override
    public List<Review> getReviewsByUserId(Long userId) {
        return reviewRepository.findByUserId(userId);
    }

    @Override
    public Review updateReview(Long id, Review review) {

        Review existingReview = reviewRepository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException(
                                "Review not found with ID: " + id
                        ));

        existingReview.setRating(review.getRating());
        existingReview.setComment(review.getComment());

        return reviewRepository.save(existingReview);
    }

    @Override
    public void deleteReview(Long id) {

        if (!reviewRepository.existsById(id)) {
            throw new RuntimeException(
                    "Review not found with ID: " + id
            );
        }

        reviewRepository.deleteById(id);
    }

    @Override
    public Double getAverageRating(Long pgId) {

        List<Review> reviews = reviewRepository.findByPgId(pgId);

        if (reviews.isEmpty()) {
            return 0.0;
        }

        double total = reviews.stream()
                .mapToInt(Review::getRating)
                .sum();

        return total / reviews.size();
    }
}