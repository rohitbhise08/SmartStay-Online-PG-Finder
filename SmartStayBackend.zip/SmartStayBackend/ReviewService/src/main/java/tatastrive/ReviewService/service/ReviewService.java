package tatastrive.ReviewService.service;

import tatastrive.ReviewService.entity.Review;

import java.util.List;

public interface ReviewService {

    Review addReview(Review review);

    List<Review> getAllReviews();

    Review getReviewById(Long id);

    List<Review> getReviewsByPgId(Long pgId);

    List<Review> getReviewsByUserId(Long userId);

    Review updateReview(Long id, Review review);

    void deleteReview(Long id);

    Double getAverageRating(Long pgId);
}