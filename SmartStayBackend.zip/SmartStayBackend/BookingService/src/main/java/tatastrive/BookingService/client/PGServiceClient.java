package tatastrive.BookingService.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Map;

@FeignClient(name = "pg-service")
public interface PGServiceClient {

    @GetMapping("/pgs/{id}")
    Map<String, Object> getPGById(
            @PathVariable("id") Long id
    );

    @PostMapping("/pgs/{id}/beds/reserve")
    String reserveBeds(
            @PathVariable("id") Long id,
            @RequestParam("count") Integer count
    );

    @PostMapping("/pgs/{id}/beds/release")
    String releaseBeds(
            @PathVariable("id") Long id,
            @RequestParam("count") Integer count
    );
}