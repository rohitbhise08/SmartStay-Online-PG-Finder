package tatastrive.BookingService.service;

import tatastrive.BookingService.dto.CreateBookingRequest;
import tatastrive.BookingService.entity.Booking;
import tatastrive.BookingService.entity.BookingStatus;

import java.util.List;

public interface BookingService {

    Booking createBooking(CreateBookingRequest request);

    Booking getBookingById(Long id);

    List<Booking> getAllBookings();

    List<Booking> getBookingsByUser(Long userId);

    List<Booking> getBookingsByPg(Long pgId);

    List<Booking> getBookingsByStatus(
            BookingStatus status
    );

    Booking updateBooking(
            Long id,
            Booking booking
    );

    Booking updateBookingStatus(
            Long id,
            BookingStatus status
    );

    void deleteBooking(Long id);
}