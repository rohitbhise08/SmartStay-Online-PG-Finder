package tatastrive.BookingService.entity;

public enum PaymentStatus {

    PENDING,
    PAID,
    FAILED,
    REFUNDED
}