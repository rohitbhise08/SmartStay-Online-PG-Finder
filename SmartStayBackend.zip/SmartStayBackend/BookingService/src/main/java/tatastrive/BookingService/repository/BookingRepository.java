package tatastrive.BookingService.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import tatastrive.BookingService.entity.Booking;
import tatastrive.BookingService.entity.BookingStatus;

import java.util.List;

public interface BookingRepository extends JpaRepository<Booking, Long> {

    List<Booking> findByUserId(Long userId);

    List<Booking> findByPgId(Long pgId);

    List<Booking> findByStatus(BookingStatus status);

    List<Booking> findByUserIdAndStatus(
            Long userId,
            BookingStatus status
    );

    List<Booking> findByPgIdAndStatus(
            Long pgId,
            BookingStatus status
    );
}