package tatastrive.BookingService.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import tatastrive.BookingService.dto.CreateBookingRequest;
import tatastrive.BookingService.entity.Booking;
import tatastrive.BookingService.entity.BookingStatus;
import tatastrive.BookingService.service.BookingService;

import java.util.List;

@RestController
@RequestMapping("/bookings")
public class BookingController {

    private final BookingService bookingService;

    public BookingController(BookingService bookingService) {
        this.bookingService = bookingService;
    }


    // =====================================================
    // CREATE BOOKING
    // =====================================================
    @PostMapping
    public ResponseEntity<Booking> createBooking(
            @RequestBody CreateBookingRequest request) {

        return new ResponseEntity<>(
                bookingService.createBooking(request),
                HttpStatus.CREATED
        );
    }


    // =====================================================
    // GET ALL BOOKINGS
    // =====================================================

    @GetMapping
    public ResponseEntity<List<Booking>> getAllBookings() {

        return ResponseEntity.ok(
                bookingService.getAllBookings()
        );
    }


    // =====================================================
    // GET BOOKING BY ID
    // =====================================================

    @GetMapping("/{id}")
    public ResponseEntity<Booking> getBooking(
            @PathVariable Long id) {

        return ResponseEntity.ok(
                bookingService.getBookingById(id)
        );
    }


    // =====================================================
    // GET BOOKINGS BY USER
    // =====================================================

    @GetMapping("/user/{userId}")
    public ResponseEntity<List<Booking>> getUserBookings(
            @PathVariable Long userId) {

        return ResponseEntity.ok(
                bookingService.getBookingsByUser(userId)
        );
    }


    // =====================================================
    // GET BOOKINGS BY PG
    // =====================================================

    @GetMapping("/pg/{pgId}")
    public ResponseEntity<List<Booking>> getPgBookings(
            @PathVariable Long pgId) {

        return ResponseEntity.ok(
                bookingService.getBookingsByPg(pgId)
        );
    }


    // =====================================================
    // GET BOOKINGS BY STATUS
    // =====================================================

    @GetMapping("/status/{status}")
    public ResponseEntity<List<Booking>> getBookingsByStatus(
            @PathVariable BookingStatus status) {

        return ResponseEntity.ok(
                bookingService.getBookingsByStatus(status)
        );
    }


    // =====================================================
    // UPDATE BOOKING
    // =====================================================

    @PutMapping("/{id}")
    public ResponseEntity<Booking> updateBooking(
            @PathVariable Long id,
            @RequestBody Booking booking) {

        return ResponseEntity.ok(
                bookingService.updateBooking(id, booking)
        );
    }


    // =====================================================
    // UPDATE STATUS
    // =====================================================
    @PatchMapping("/{id}/status")
    public ResponseEntity<Booking> updateStatus(
            @PathVariable Long id,
            @RequestParam("status") BookingStatus status) {

        return ResponseEntity.ok(
                bookingService.updateBookingStatus(
                        id,
                        status
                )
        );
    }


    // =====================================================
    // DELETE BOOKING
    // =====================================================

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteBooking(
            @PathVariable Long id) {

        bookingService.deleteBooking(id);

        return ResponseEntity.ok(
                "Booking deleted successfully"
        );
    }
}