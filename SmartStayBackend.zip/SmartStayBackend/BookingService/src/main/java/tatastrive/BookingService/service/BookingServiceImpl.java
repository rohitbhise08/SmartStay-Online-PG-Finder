package tatastrive.BookingService.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import tatastrive.BookingService.client.PGServiceClient;
import tatastrive.BookingService.dto.CreateBookingRequest;
import tatastrive.BookingService.entity.Booking;
import tatastrive.BookingService.entity.BookingStatus;
import tatastrive.BookingService.entity.PaymentStatus;
import tatastrive.BookingService.exception.BookingNotFoundException;
import tatastrive.BookingService.repository.BookingRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@Service
public class BookingServiceImpl implements BookingService {

    private final BookingRepository bookingRepository;
    private final PGServiceClient pgServiceClient;

    public BookingServiceImpl(
            BookingRepository bookingRepository,
            PGServiceClient pgServiceClient) {

        this.bookingRepository = bookingRepository;
        this.pgServiceClient = pgServiceClient;
    }

    // =========================================================
    // CREATE BOOKING
    // =========================================================

    @Override
    @Transactional
    public Booking createBooking(CreateBookingRequest request) {

        // -----------------------------------------------------
        // Validate request
        // -----------------------------------------------------

        if (request == null) {
            throw new RuntimeException(
                    "Booking request cannot be null"
            );
        }

        if (request.getUserId() == null) {
            throw new RuntimeException(
                    "User ID is required"
            );
        }

        if (request.getPgId() == null) {
            throw new RuntimeException(
                    "PG ID is required"
            );
        }

        if (request.getCheckInDate() == null) {
            throw new RuntimeException(
                    "Check-in date is required"
            );
        }

        if (request.getCheckOutDate() != null &&
                !request.getCheckOutDate()
                        .isAfter(request.getCheckInDate())) {

            throw new RuntimeException(
                    "Check-out date must be after check-in date"
            );
        }

        if (request.getNumberOfBeds() == null ||
                request.getNumberOfBeds() <= 0) {

            throw new RuntimeException(
                    "Number of beds must be greater than zero"
            );
        }

        // -----------------------------------------------------
        // Get PG details
        // -----------------------------------------------------

        Map<String, Object> pg;

        try {

            pg = pgServiceClient.getPGById(
                    request.getPgId()
            );

        } catch (Exception e) {

            throw new RuntimeException(
                    "Unable to connect to PG Service: "
                            + e.getMessage()
            );
        }

        if (pg == null || pg.isEmpty()) {

            throw new RuntimeException(
                    "PG not found with ID: "
                            + request.getPgId()
            );
        }

        // -----------------------------------------------------
        // Check PG status
        // -----------------------------------------------------

        Object statusObject = pg.get("status");

        if (statusObject == null) {

            throw new RuntimeException(
                    "PG status information is missing"
            );
        }

        String pgStatus =
                statusObject.toString();

        if (!"ACTIVE".equalsIgnoreCase(pgStatus)) {

            throw new RuntimeException(
                    "PG is not active and cannot be booked"
            );
        }

        // -----------------------------------------------------
        // Check available beds
        // -----------------------------------------------------

        Object availableBedsObject =
                pg.get("availableBeds");

        if (!(availableBedsObject instanceof Number)) {

            throw new RuntimeException(
                    "Invalid available beds information from PG Service"
            );
        }

        int availableBeds =
                ((Number) availableBedsObject).intValue();

        int requestedBeds =
                request.getNumberOfBeds();

        if (availableBeds < requestedBeds) {

            throw new RuntimeException(
                    "Not enough beds available. Available: "
                            + availableBeds
                            + ", Requested: "
                            + requestedBeds
            );
        }

        // -----------------------------------------------------
        // Get monthly rent
        // -----------------------------------------------------

        Object monthlyRentObject =
                pg.get("monthlyRent");

        if (!(monthlyRentObject instanceof Number)) {

            throw new RuntimeException(
                    "Invalid monthly rent information from PG Service"
            );
        }

        double monthlyRent =
                ((Number) monthlyRentObject).doubleValue();

        // -----------------------------------------------------
        // Get security deposit
        // -----------------------------------------------------

        double securityDeposit = 0.0;

        Object securityDepositObject =
                pg.get("securityDeposit");

        if (securityDepositObject instanceof Number) {

            securityDeposit =
                    ((Number) securityDepositObject).doubleValue();
        }

        // -----------------------------------------------------
        // Calculate total amount
        // -----------------------------------------------------

        double totalAmount =
                (monthlyRent * requestedBeds)
                        + securityDeposit;

        // -----------------------------------------------------
        // Create Booking entity
        // -----------------------------------------------------

        Booking booking = new Booking();

        booking.setUserId(
                request.getUserId()
        );

        booking.setPgId(
                request.getPgId()
        );

        booking.setCheckInDate(
                request.getCheckInDate()
        );

        booking.setCheckOutDate(
                request.getCheckOutDate()
        );

        booking.setNumberOfBeds(
                requestedBeds
        );

        booking.setMonthlyRent(
                monthlyRent
        );

        booking.setSecurityDeposit(
                securityDeposit
        );

        booking.setTotalAmount(
                totalAmount
        );

        booking.setSpecialRequest(
                request.getSpecialRequest()
        );

        booking.setStatus(
                BookingStatus.PENDING
        );

        booking.setPaymentStatus(
                PaymentStatus.PENDING
        );

        // -----------------------------------------------------
        // Reserve beds
        // -----------------------------------------------------

        boolean bedsReserved = false;

        try {

            pgServiceClient.reserveBeds(
                    request.getPgId(),
                    requestedBeds
            );

            bedsReserved = true;

        } catch (Exception e) {

            throw new RuntimeException(
                    "Unable to reserve beds: "
                            + e.getMessage()
            );
        }

        // -----------------------------------------------------
        // Save booking
        // -----------------------------------------------------

        try {

            return bookingRepository.save(booking);

        } catch (Exception e) {

            // If database save fails after beds were reserved,
            // release the beds again.

            if (bedsReserved) {

                try {

                    pgServiceClient.releaseBeds(
                            request.getPgId(),
                            requestedBeds
                    );

                } catch (Exception releaseException) {

                    // Do not hide the original database error.
                }
            }

            throw new RuntimeException(
                    "Unable to save booking: "
                            + e.getMessage()
            );
        }
    }

    // =========================================================
    // GET BOOKING BY ID
    // =========================================================

    @Override
    public Booking getBookingById(Long id) {

        return bookingRepository.findById(id)
                .orElseThrow(
                        () -> new BookingNotFoundException(id)
                );
    }

    // =========================================================
    // GET ALL BOOKINGS
    // =========================================================

    @Override
    public List<Booking> getAllBookings() {

        return bookingRepository.findAll();
    }

    // =========================================================
    // GET BOOKINGS BY USER
    // =========================================================

    @Override
    public List<Booking> getBookingsByUser(Long userId) {

        return bookingRepository.findByUserId(userId);
    }

    // =========================================================
    // GET BOOKINGS BY PG
    // =========================================================

    @Override
    public List<Booking> getBookingsByPg(Long pgId) {

        return bookingRepository.findByPgId(pgId);
    }

    // =========================================================
    // GET BOOKINGS BY STATUS
    // =========================================================

    @Override
    public List<Booking> getBookingsByStatus(
            BookingStatus status) {

        return bookingRepository.findByStatus(status);
    }

    // =========================================================
    // UPDATE BOOKING
    // =========================================================

    @Override
    public Booking updateBooking(
            Long id,
            Booking booking) {

        Booking existing =
                getBookingById(id);

        if (booking.getCheckInDate() != null) {

            existing.setCheckInDate(
                    booking.getCheckInDate()
            );
        }

        if (booking.getCheckOutDate() != null) {

            if (existing.getCheckInDate() != null &&
                    !booking.getCheckOutDate()
                            .isAfter(existing.getCheckInDate())) {

                throw new RuntimeException(
                        "Check-out date must be after check-in date"
                );
            }

            existing.setCheckOutDate(
                    booking.getCheckOutDate()
            );
        }

        existing.setSpecialRequest(
                booking.getSpecialRequest()
        );

        return bookingRepository.save(existing);
    }

    // =========================================================
    // UPDATE BOOKING STATUS
    // =========================================================

    @Override
    @Transactional
    public Booking updateBookingStatus(
            Long id,
            BookingStatus status) {

        if (status == null) {
            throw new RuntimeException(
                    "Booking status cannot be null"
            );
        }

        Booking booking = getBookingById(id);

        BookingStatus currentStatus = booking.getStatus();

        if (currentStatus == BookingStatus.CANCELLED) {
            throw new RuntimeException(
                    "Cancelled booking cannot be updated"
            );
        }

        if (currentStatus == BookingStatus.COMPLETED) {
            throw new RuntimeException(
                    "Completed booking cannot be updated"
            );
        }

        booking.setStatus(status);

        return bookingRepository.save(booking);
    }
    // =========================================================
    // DELETE BOOKING
    // =========================================================

    @Override
    @Transactional
    public void deleteBooking(Long id) {

        Booking booking = getBookingById(id);

        if (booking.getStatus() == BookingStatus.COMPLETED) {
            throw new RuntimeException(
                    "Completed booking cannot be deleted"
            );
        }

        if (booking.getStatus() == BookingStatus.PENDING ||
                booking.getStatus() == BookingStatus.CONFIRMED) {

            try {

                pgServiceClient.releaseBeds(
                        booking.getPgId(),
                        booking.getNumberOfBeds()
                );

            } catch (Exception e) {

                throw new RuntimeException(
                        "Unable to release beds in PG Service: "
                                + e.getMessage()
                );
            }
        }

        bookingRepository.delete(booking);
    }
}