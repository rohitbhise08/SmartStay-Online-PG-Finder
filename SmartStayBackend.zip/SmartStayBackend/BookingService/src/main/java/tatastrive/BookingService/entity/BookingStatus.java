package tatastrive.BookingService.entity;

public enum BookingStatus {

    PENDING,
    CONFIRMED,
    CANCELLED,
    COMPLETED,
    REJECTED
}