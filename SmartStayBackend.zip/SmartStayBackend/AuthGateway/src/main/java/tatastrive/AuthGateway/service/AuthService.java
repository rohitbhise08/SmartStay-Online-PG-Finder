package tatastrive.AuthGateway.service;

import tatastrive.AuthGateway.dto.AuthResponse;
import tatastrive.AuthGateway.dto.LoginRequest;
import tatastrive.AuthGateway.dto.RegisterRequest;

public interface AuthService {

    AuthResponse register(RegisterRequest request);

    AuthResponse login(LoginRequest request);
}