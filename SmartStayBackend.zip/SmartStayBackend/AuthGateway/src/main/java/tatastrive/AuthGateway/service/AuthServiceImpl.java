package tatastrive.AuthGateway.service;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import tatastrive.AuthGateway.dto.AuthResponse;
import tatastrive.AuthGateway.dto.LoginRequest;
import tatastrive.AuthGateway.dto.RegisterRequest;
import tatastrive.AuthGateway.entity.Role;
import tatastrive.AuthGateway.entity.User;
import tatastrive.AuthGateway.repository.RoleRepository;
import tatastrive.AuthGateway.repository.UserRepository;
import tatastrive.AuthGateway.security.JwtService;

@Service
public class AuthServiceImpl implements AuthService {

    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;

    public AuthServiceImpl(
            UserRepository userRepository,
            RoleRepository roleRepository,
            PasswordEncoder passwordEncoder,
            JwtService jwtService) {

        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtService = jwtService;
    }
    @Override
    public AuthResponse register(RegisterRequest request) {

        System.out.println("REGISTER REQUEST: " + request.getEmail());

        if (userRepository.existsByEmail(request.getEmail())) {

            System.out.println("EMAIL ALREADY EXISTS");

            return new AuthResponse(
                    null,
                    "Email already registered",
                    null,
                    null,
                    request.getEmail(),
                    null
            );
        }

        System.out.println("EMAIL IS NEW");

        String roleName = request.getRole();

        if (roleName == null || roleName.isBlank()) {
            roleName = "ROLE_USER";
        }

        if (!roleName.startsWith("ROLE_")) {
            roleName = "ROLE_" + roleName.toUpperCase();
        }

        System.out.println("ROLE: " + roleName);

        Role role = roleRepository
                .findByRoleName(roleName)
                .orElse(null);

        if (role == null) {

            System.out.println("ROLE DOES NOT EXIST - CREATING");

            role = new Role();
            role.setRoleName(roleName);

            role = roleRepository.save(role);
        }

        System.out.println("ROLE ID: " + role.getId());

        User user = new User();

        user.setFullName(request.getFullName());
        user.setEmail(request.getEmail());

        user.setPassword(
                passwordEncoder.encode(
                        request.getPassword()
                )
        );
        user.setPhone(request.getPhone());
        user.setStatus("ACTIVE");
        user.setRole(role);

        System.out.println("SAVING USER");

        User savedUser = userRepository.save(user);

        System.out.println("USER SAVED: " + savedUser.getId());

        String token = jwtService.generateToken(
                savedUser.getEmail(),
                role.getRoleName()
        );

        return new AuthResponse(
                token,
                "Registration successful",
                savedUser.getId(),
                savedUser.getFullName(),
                savedUser.getEmail(),
                role.getRoleName()
        );
    }

    @Override
    public AuthResponse login(
            LoginRequest request) {

        User user = userRepository
                .findByEmail(request.getEmail())
                .orElseThrow(() ->
                        new RuntimeException(
                                "Invalid email or password"
                        )
                );

        boolean passwordMatches =
                passwordEncoder.matches(
                        request.getPassword(),
                        user.getPassword()
                );

        if (!passwordMatches) {

            throw new RuntimeException(
                    "Invalid email or password"
            );
        }

        String role = user.getRole().getRoleName();

        String token = jwtService.generateToken(
                user.getEmail(),
                role
        );

        return new AuthResponse(
                token,
                "Login successful",
                user.getId(),
                user.getFullName(),
                user.getEmail(),
                role
        );
    }
}