package tatastrive.AuthGateway.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import tatastrive.AuthGateway.entity.Role;

import java.util.Optional;

public interface RoleRepository extends JpaRepository<Role, Long> {

    Optional<Role> findByRoleName(String roleName);
}